# Port Solara

An original open-world action game for **Android** and **Windows 10/11**, built with **Unity 6 (C#)**.

> **Status: v0.1 playable prototype (Milestone 0).** One character, one car, a small procedural coastal city, working controls on keyboard/mouse, gamepad and touch, plus menus, settings, save/load, a day–night cycle and one tutorial mission. Everything else in the [Game Design Document](Docs/GameDesignDocument.md) is **planned, not built**. See [Docs/Roadmap.md](Docs/Roadmap.md) for what's done and what's next.

Port Solara is an original IP. It contains no assets, names, maps, music, characters or trademarks from any other game. All prototype visuals are generated in code from Unity primitives.

---

## What works in v0.1

| Area | Implemented |
|---|---|
| World | Procedural 6×6-block city (seeded), ring roads, lane markings, parks with trees, street lamps, beach, sea, countryside, world bounds |
| Day/night | 16-minute day, moving sun, ambient/fog colour, street lamps light up at night |
| Player | Third-person walk / sprint / jump / swim, camera-relative movement, procedural walk cycle |
| Vehicle | WheelCollider car: throttle, brake/reverse, speed-sensitive steering, handbrake slides, anti-roll, downforce, collision damage → less power → wrecked, flip reset, flooding, repair at garage, tow when wrecked |
| Camera | Orbit camera with collision, auto-recentre behind car, menu fly-over |
| Controls | Keyboard + mouse (rebindable), gamepad (Xbox/PlayStation/generic via Input System), touch (joystick, look-drag, contextual buttons), safe-area aware |
| UI | Main menu, pause, settings (quality, FPS cap, render resolution on mobile, draw distance, V-Sync, display mode, sensitivity, invert Y, touch mode/size/opacity, minimap), key bindings, HUD, minimap + full map |
| Save | JSON save slot with atomic write + backup; autosave when the app is backgrounded on mobile |
| Mission | "First Drive" — enter car → 3 checkpoints → park at garage |
| Tooling | One-click scene/player-settings setup, menu + CLI builds (EXE, APK, AAB), EditMode + PlayMode tests, GitHub Actions CI |

**Not yet implemented** (planned, see roadmap): traffic, pedestrians, police, weather, interiors, second protagonist, customization, more vehicle types, story, audio, real art.

---

## Requirements

- **Unity Hub** + **Unity 6 LTS** (6000.0.x — use the latest patch; recent patches support Android API 36 and 16 KB page sizes)
- Unity modules: **Android Build Support** (with OpenJDK + Android SDK & NDK tools) and **Windows Build Support (Mono)**
- Git + **Git LFS**
- A Windows PC or Mac for the Editor; an Android phone (Android 8.0+, ARM64) with USB debugging for device tests

---

## Getting started (≈10 minutes)

The repository holds the game's `Assets/` folder. Unity generates `ProjectSettings/` and `Packages/` when you create the project, so you create a fresh project and add the code to it:

1. **Create the project.** Unity Hub ▸ New project ▸ **Universal 3D** template (URP), Unity 6. Name it `PortSolara`.
   - The template already includes the **Input System** and **uGUI** packages. If yours doesn't, install *Input System* from Window ▸ Package Manager.
   - Edit ▸ Project Settings ▸ Player ▸ *Active Input Handling* must be **Input System Package (New)** or **Both**.
2. **Add this repo.** Copy the `Assets/_Project` folder, `Docs/`, `.github/`, `.gitignore`, `.gitattributes` and this README into the project folder. (Or: `git init` inside the project, add this repo as `origin`, `git pull origin main --allow-unrelated-histories`.)
3. **Create the scene.** Menu **Tools ▸ Port Solara ▸ 1. Create or Repair Main Scene**.
4. **Apply settings.** **Tools ▸ Port Solara ▸ 2. Apply Recommended Player Settings** (landscape, IL2CPP/ARM64, target API 36, app icon).
5. **Press Play.** Click *New Game*.
6. **Commit everything** (including the generated `ProjectSettings/` and `Packages/`) and push to GitHub so CI can build it:
   ```bash
   git lfs install
   git add .
   git commit -m "Add Port Solara prototype"
   git branch -M main
   git remote add origin https://github.com/<you>/PortSolara.git
   git push -u origin main
   ```

Before your first Play Store upload, change `ApplicationId` in `Assets/_Project/Scripts/Editor/ProjectSetup.cs` (it can never change after you publish).

---

## Controls

| Action | Keyboard / Mouse | Gamepad | Touch |
|---|---|---|---|
| Move / steer | W A S D | Left stick | Left joystick |
| Look | Mouse | Right stick | Drag right side of screen |
| Sprint | Left Shift | LB / L3 | RUN (hold) |
| Jump | Space | A / Cross | JUMP |
| Accelerate / brake-reverse | W / S | RT / LT | GAS / BRAKE |
| Handbrake | Space | A / RB | DRIFT |
| Enter / exit vehicle | F | Y / Triangle | ENTER / EXIT |
| Reset or tow vehicle | R | D-pad Up | RESET |
| Map | M | View/Select | Tap minimap |
| Pause / back | Esc | Start / B (back) | II |
| Screenshot (PC) | F12 | — | — |

Keyboard keys are rebindable in **Settings ▸ Key Bindings**. To try touch controls in the Editor, set **Settings ▸ Touch Controls ▸ On** and use the mouse.

---

## Testing

- **Editor tests:** Window ▸ General ▸ Test Runner → *EditMode* (city layout, save system, key bindings) and *PlayMode* (boots the full game; tests spawn, physics settling, enter/exit vehicle, save/load, pause).
- **Manual test plan:** [Docs/Testing.md](Docs/Testing.md). Run it separately on Windows and on at least one low-end and one mid-range Android phone.
- **Performance:** Window ▸ Analysis ▸ Profiler with *Development Build* + *Autoconnect Profiler* on the device.

## Building

| Target | From the Editor | Output |
|---|---|---|
| Windows x64 | Tools ▸ Port Solara ▸ Build ▸ Windows (x64) | `Builds/Windows/PortSolara.exe` |
| Android APK (sideload / test) | Tools ▸ Port Solara ▸ Build ▸ Android APK | `Builds/Android/PortSolara.apk` |
| Android App Bundle (Play) | Tools ▸ Port Solara ▸ Build ▸ Android App Bundle | `Builds/Android/PortSolara.aab` |

Install an APK on a phone: `adb install -r Builds/Android/PortSolara.apk`.

To build an AAB you can upload to Google Play, you need an upload keystore (Player Settings ▸ Publishing Settings ▸ Keystore Manager). **Never commit the keystore.** Back it up somewhere safe.

### CI (GitHub Actions)

`.github/workflows/ci.yml` runs all tests on every push and PR, then builds Windows and Android on `main`, on `v*` tags and on manual runs, and uploads the builds as workflow artifacts. Add these repository secrets:

| Secret | Purpose |
|---|---|
| `UNITY_LICENSE`, `UNITY_EMAIL`, `UNITY_PASSWORD` | Unity activation ([GameCI activation guide](https://game.ci/docs/github/activation)) |
| `ANDROID_KEYSTORE_BASE64` | `base64 -w0 upload.keystore` |
| `ANDROID_KEYSTORE_PASS`, `ANDROID_KEYALIAS_NAME`, `ANDROID_KEYALIAS_PASS` | Keystore credentials |

Without the keystore secrets, the Android job still builds, but the AAB is debug-signed and Play will reject it.

---

## Repository layout

```
Assets/_Project/
  Art/Icons/            App icon (original, generated)
  Scenes/               Main.unity (created by Tools ▸ Port Solara)
  Scripts/Runtime/      Game code (PortSolara.Runtime.asmdef)
    Core/               GameManager (composition root + state machine), materials, primitives
    Input/              InputRouter (KB/M + gamepad + touch → GameInput), KeyBindings
    Player/             PlayerController
    CameraSystem/       ThirdPersonCamera
    Vehicles/           VehicleController, RepairZone
    World/              CityLayout (pure data), CityBuilder, DayNightCycle, WorldQuery
    Missions/           MissionManager
    Save/               SaveSystem, SaveData
    Settings/           GameSettings
    UI/                 GameUI, menus, touch widgets, minimap, UIFactory
  Scripts/Editor/       ProjectSetup, BuildScript (PortSolara.Editor.asmdef)
  Tests/EditMode|PlayMode
Docs/                   GDD, architecture, roadmap, testing, Play Store kit
.github/workflows/      CI
```

Details: [Docs/Architecture.md](Docs/Architecture.md).

## Licence

Code: MIT (see `LICENSE`). Game name, story and generated art: © the project owner, all rights reserved.
