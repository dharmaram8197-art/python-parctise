# Development Roadmap

Status key: ✅ done · 🔨 in progress · ⬜ planned

Durations assume a **core team of 4–6** (2 programmers, 2 artists, 1 designer, part-time audio/QA) using marketplace assets. A solo developer should multiply them by roughly 3–4.

## M0 — Playable prototype ✅ (this repository, v0.1)
- ✅ Architecture, repo, CI, tests, docs
- ✅ Procedural small city, beach, sea, day/night
- ✅ One character (walk/sprint/jump/swim), one car (physics, damage, repair)
- ✅ KB/M + gamepad + touch controls, rebinding, settings, save/load, minimap, tutorial mission
- **Exit criteria:** Windows build at a stable 60 fps; Android build at 30 fps on a mid-range phone; manual test plan passes on both.

## M1 — Core feel (≈ 2–3 months)
- ⬜ Rigged humanoid with Animator (locomotion blend tree, jump, swim, enter/exit car animations)
- ⬜ Car audio (engine RPM layers, tyre squeal, impacts), first music
- ⬜ Vehicle data as ScriptableObjects; add bike, sports car, truck
- ⬜ Visual damage (mesh deformation, detachable parts), smoke/fire VFX
- ⬜ Weather system: rain, storm, fog, wet roads (URP decals + puddle shader)
- ⬜ Garage: paint, wheels, performance tuning
- ⬜ Second protagonist + character switch; basic customization (outfits)

## M2 — Living city (≈ 3–4 months)
- ⬜ Road lane graph generated from the city layout; AI traffic with lights and lane changes
- ⬜ Pedestrians (navmesh, schedules, reactions)
- ⬜ Police & wanted system (1–5 stars, pursuit AI, roadblocks, helicopter)
- ⬜ World streaming (Addressables, 256 m tiles), HLOD skyline
- ⬜ Enterable shops and safehouse interiors (additive scenes)
- ⬜ Boats (buoyancy) and a helicopter

## M3 — Vertical slice (≈ 3 months)
- ⬜ One hand-dressed district (Old Town + Palmetto Strand) with final-quality art
- ⬜ Mission system v2: data-driven graph, dialogue, cutscenes, fail/retry
- ⬜ Act I story missions (5–6), 3 side-job types, street racing
- ⬜ Full map/waypoint routing, phone UI
- ⬜ Accessibility pass (subtitles, colour-blind safe HUD, hold-to-toggle options)
- **Milestone use:** pitch to publishers/investors, Steam page, closed tests

## M4 — Content production (≈ 6–12 months)
- ⬜ Remaining districts, Acts II–III, 25 story missions, 30+ side activities
- ⬜ 25+ vehicles, airport, port
- ⬜ Localization (EN, HI, ES, PT-BR at least)

## M5 — Launch prep
- ⬜ Performance and memory pass per device tier; thermal/battery soak tests (1 h)
- ⬜ Google Play closed testing (personal developer accounts must run a closed test with a minimum number of testers for 14 days before production; check the current requirement in Play Console)
- ⬜ IARC rating, Data Safety form, privacy policy hosting
- ⬜ PC: Steam/itch store pages, controller glyphs, ultrawide support
- ⬜ Launch: PC Early Access → Android

## Immediate next tasks (start of M1)
1. Import a CC0 or commercially licensed humanoid (Mixamo characters and animations are free to use in games) and replace the placeholder mannequin; keep `PlayerController` and drive the Animator from `Speed`/`State`.
2. Swap primitive buildings for a modular building kit via a `BuildingSet` ScriptableObject used by `CityBuilder`.
3. Add `VehicleDefinition` ScriptableObject → `VehicleController.spec`.
4. Add an audio manager plus engine sound.
5. Profile on a real low-end Android device and record a baseline in `Docs/Performance.md`.
