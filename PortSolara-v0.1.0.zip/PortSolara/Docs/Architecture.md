# Architecture

## Principles
1. **One composition root.** `GameManager` builds every system in `Awake()` and wires them explicitly. There is no hidden inspector wiring, so the whole game starts from one empty scene with one component.
2. **Data separate from GameObjects.** `CityLayout` is plain C#: deterministic, unit-tested, and reusable for streaming, minimaps and AI lane graphs. `CityBuilder` turns it into objects.
3. **Input is abstracted.** Gameplay reads `InputRouter.Current` (a `GameInput` struct). Keyboard/mouse, gamepad and touch are merged in one place, so adding a new device touches one file.
4. **Each assembly has one job.** `PortSolara.Runtime`, `PortSolara.Editor`, `PortSolara.Tests.*` are separate assemblies, which gives faster compiles and enforced boundaries.
5. **Mobile-first budgets.** Shared materials, static batching, a 30 fps default on phones, render-scale control, sleep-timeout management and autosave on backgrounding.

## Runtime flow

```
Scene "Main"
 └─ Game (GameManager + InputRouter)
      Awake():
        CityLayout(seed) ─► CityBuilder.Build() ─► World/City (static-batched)
        Sun + DayNightCycle, Main Camera + ThirdPersonCamera
        PlayerController.Create(), VehicleController.Create(), RepairZone
        MissionManager.Init(), GameUI.Init()
        GameSettings.Apply() → State = MainMenu
```

### State machine (`GameState`)

```
MainMenu ──New Game / Continue──► Playing ◄──Resume── Paused
    ▲                                │ Esc/Start/II        │
    └────────── Quit to Main Menu ───┴─────────────────────┘
```
`Time.timeScale` is 1 only in `Playing`. Menus use unscaled time.

### Execution order
| Order | Script | Why |
|---|---|---|
| -100 | `InputRouter` | Input sampled before anyone reads it |
| -50 | `GameManager` | Handles pause/interact and sets the player's camera-relative yaw before the player moves |
| 0 | Player, vehicle, missions, UI | |
| +100 (LateUpdate) | `ThirdPersonCamera` | Follows final positions |

## Module reference

| Module | Key types | Responsibility |
|---|---|---|
| Core | `GameManager`, `MaterialLibrary`, `Primitives` | Flow, save/load orchestration, enter/exit vehicle, cursor and sleep management |
| Input | `InputRouter`, `GameInput`, `KeyBindings`, `KeyBindingsStore` | Device merge, dead zones, rebinding and persistence |
| Player | `PlayerController` | CharacterController movement, swimming, fall recovery |
| CameraSystem | `ThirdPersonCamera` | Orbit, collision (SphereCast ignoring target), recentring |
| Vehicles | `VehicleController` (+`VehicleSpec`), `RepairZone` | Physics, damage model, flooding, reset/tow, exit-point search |
| World | `CityLayout`, `CityBuilder`, `DayNightCycle`, `WorldQuery` | Generation, lighting, water queries |
| Missions | `MissionManager` | Objective state machine, marker, notifications |
| Save | `SaveSystem`, `SaveData` | Versioned JSON, atomic write (tmp → move), `.bak` fallback, validation |
| Settings | `GameSettings` | PlayerPrefs persistence; applies quality/FPS/V-Sync/fullscreen/render scale |
| UI | `GameUI`, `MenuScreen`s, `Minimap`, touch widgets, `UIFactory` | Code-built uGUI, safe area, multi-touch |

## Error handling
- Save/load never throws to callers; it returns `bool` plus a user-readable message shown in the UI. Corrupted saves fall back to the backup, and invalid data (NaN, future version) is rejected.
- Settings are clamped on load and save, so bad PlayerPrefs can't crash the game.
- Key bindings ignore malformed entries, and Escape can't be bound (no lock-out).
- World build failures are logged with a full exception and re-thrown, never silently swallowed.
- Players and vehicles have recovery paths: fall-through respawn, flip reset, tow when wrecked, exit-point search when blocked.

## Extending
- **New vehicle:** create a `VehicleSpec` (later a ScriptableObject) and a visual prefab, then reuse `VehicleController`.
- **New mission:** the prototype `MissionManager` is linear on purpose. M3 replaces it with a data-driven graph that keeps the same `Objective`/`CurrentTarget`/`Notification` surface, so the HUD and minimap don't change.
- **Real art:** replace `Primitives.*` calls in `CityBuilder`, `PlayerController.BuildVisual` and `VehicleController.Build` with prefab instantiation. Gameplay code is unaffected.
