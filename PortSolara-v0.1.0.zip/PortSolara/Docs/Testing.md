# Test Plan

## Automated (Unity Test Runner / CI)
| Suite | Covers |
|---|---|
| EditMode `CityLayoutTests` | Determinism, buildings never on roads, spawns/checkpoints on roads, water region, invalid sizes |
| EditMode `SaveSystemTests` | Round trip, corrupted file → backup, missing save, future version rejected |
| EditMode `KeyBindingsTests` | Defaults, serialise/parse, Escape rejected, garbage input |
| PlayMode `GameSmokeTests` | Full boot to main menu, player/vehicle settle on ground, vehicle upright, enter/exit, save/load, pause timeScale |

## Manual — run on **Windows** and **Android** separately

Record device, OS, build number, average fps (Development build + `Profiler`), and pass/fail.

### Boot & menus
- [ ] Game boots to main menu with city fly-over; no errors in console/logcat
- [ ] *Continue* disabled with "no save yet" on a fresh install
- [ ] Every button on main, pause, settings and key-binding screens does what it says
- [ ] Gamepad can navigate all menus (D-pad + A), B goes back
- [ ] Esc/Start pauses; Esc in settings returns to previous screen

### On foot
- [ ] Walk, sprint, jump on flat ground, kerbs and park lawns
- [ ] Camera never clips inside buildings when backed against walls
- [ ] Walk into the sea → swims with head above water → can return to beach
- [ ] Prompt "Press F to drive" appears only near the car

### Vehicle
- [ ] Enter/exit from both sides; exit blocked side picks another side
- [ ] Accelerate to >150 km/h on the ring road; steering stable at speed
- [ ] Brake, reverse, handbrake slide
- [ ] Crash into buildings: condition drops, paint darkens, top speed falls
- [ ] Wreck the car → "Reset to tow" → car appears at garage → stand on blue pad → repairs to 100%
- [ ] Flip the car → Reset puts it upright
- [ ] Drive into the sea → "Flooded" → exit and swim

### Mission
- [ ] Enter car → checkpoint 1 → 2 → 3 → garage → "Mission complete"
- [ ] Pause ▸ Restart Mission works mid-way and after completion

### Save/Load
- [ ] Save while driving at night with damaged car → quit to menu → Continue: same position, in car, same time, same damage, same mission stage
- [ ] Android: press Home mid-drive → reopen → game is paused and progress autosaved

### Settings
- [ ] Each quality level visibly changes (shadows/AA) and persists after restart
- [ ] FPS cap 30/60/120 honoured (PC with V-Sync off; Android)
- [ ] Android render resolution 50–100% changes sharpness and GPU time
- [ ] Draw distance changes fog/far clip
- [ ] PC: Fullscreen/Windowed toggle works; V-Sync toggle works
- [ ] Sensitivity and invert-Y affect mouse, right stick and touch drag
- [ ] Key rebinding works, persists, Esc cancels, "Reset Bindings" restores WASD

### Touch (Android, plus Editor with Touch Controls = On)
- [ ] Joystick + look-drag + GAS simultaneously (3 fingers)
- [ ] ENTER only visible near the car; EXIT/RESET only while driving
- [ ] Buttons respect safe area on notched/punch-hole phones; tablets 4:3 and phones 20:9
- [ ] Button size and opacity settings apply immediately
- [ ] Tapping minimap opens full map; tapping again closes it

### Performance & battery (Android)
- [ ] 30 min play session: no thermal throttling below 25 fps on mid-range device
- [ ] Memory under 1.2 GB (Profiler ▸ Memory)
- [ ] Screen sleeps normally in menus, stays awake while playing

## Device matrix (minimum)
| Tier | Example | Target |
|---|---|---|
| Low | 3 GB RAM, Mali-G52 class | Lowest quality, 30 fps, 70% res |
| Mid | 6 GB RAM, Adreno 6xx class | Medium, 30–60 fps |
| High | Flagship 2024+ | High, 60 fps |
| PC min | GTX 1050 / i5-6th gen, 8 GB | Medium 60 fps 1080p |
