# Port Solara — Game Design Document

*Version 0.1 · living document · original IP*

## 1. Vision

**High concept:** A sun-soaked, satirical crime-adventure in a fictional modern coastal state. Two original protagonists climb from small-time hustles to running the coast, told through story missions, open-world driving and police chases.

**Pillars**
1. **The city is the main character.** Dense downtown, beach strip, port, airport, swamp villages and farmland, all with day/night and weather changes.
2. **Driving feels great on any device.** Arcade-leaning physics that read well with thumbs and with a wheel or gamepad.
3. **Two lives, one story.** Switch between two protagonists whose missions overlap.
4. **Plays well on phones.** Every feature has a mobile budget from day one. Scale up on PC; never port down later.

**Inspiration, not imitation:** The genre (open-world crime action) is shared with titles like the GTA series. Port Solara uses **no** names, map layouts, characters, music, logos or story beats from any existing game. The store listing must never mention other franchises (Google Play metadata policy and trademark law).

**Targets:** Android 8.0+ (ARM64, Vulkan/GLES3), Windows 10/11 x64. Landscape only. Rating target is Teen/PEGI 16 at launch, decided by the content choices in §9.

## 2. Setting — the State of Solara

| District | Description | Gameplay |
|---|---|---|
| **Old Town** (prototype area) | Grid downtown, mid-rise offices, plazas | Story hub, street races |
| **Glass Mile** | Skyscraper financial core | Rooftop helipads, heists (later) |
| **Palmetto Strand** | Beach boardwalk, hotels, marina | Boats, nightlife, side jobs |
| **Saltworks Port** | Container terminal, cranes, rail yard | Trucks, smuggling missions |
| **Solara International** | Airport + private hangars | Helicopters, planes (late) |
| **Cypress Bend** | Swamp villages on stilts, airboats | Off-road, wildlife |
| **Highland Farms** | Countryside, highways, small towns | Long drives, trucking, races |

Scale goal: about 8×8 km on PC and about 4×4 km on mobile at launch, streamed in 256 m tiles.

## 3. Characters (original)

- **Rhea Valdés (28)** — ex-paramedic turned getaway driver. Cool under pressure, dry humour. Specialty: driving (slow-motion focus while drifting).
- **Kofi Mensah-Hart (33)** — charismatic small-business owner in debt to the wrong people. Specialty: negotiation and stealth (lower wanted-level gain).
- **Supporting cast:** Auntie Marisol (Rhea's grandmother, mechanic, runs the garage), Detective Ike Brandt (the antagonist cop), "Silk" Dorsey (crime-boss rival), Benny Tran (hacker friend).
- **Customization:** hair, clothes, accessories, tattoos (cosmetic). Body sliders are planned for a later free-roam avatar mode.

## 4. Story outline (three acts, ~25 main missions)

1. **Act I – Heatwave.** Rhea drives for a robbery crew that gets double-crossed. Kofi's shop is torched by Silk's crew. The two meet when Rhea's getaway car crashes into his lot.
2. **Act II – High Tide.** The pair work jobs across the port and the strand to pay Kofi's debt. Detective Brandt closes in, and the crew learns that Brandt is on Silk's payroll.
3. **Act III – Landfall.** During a hurricane they expose Brandt and take down Silk at the airport. There are two endings (leave Solara, or take over the coast).

The tone is satire of influencer culture, real-estate speculation and tourism. Violence stays non-graphic.

## 5. Core loop

Explore → take a job (story, side, race, delivery) → drive/chase → earn cash and reputation → upgrade cars, garage, outfits → unlock districts and missions.

**Wanted system (planned):** 1–5 heat levels. Police AI escalates from patrol cars to roadblocks to a helicopter. Lose them by breaking line of sight, hiding in alleys or changing vehicles. Respawn at a clinic, losing a small amount of cash.

## 6. Systems

| System | Prototype (v0.1) | Launch target |
|---|---|---|
| On-foot movement | Walk/sprint/jump/swim | + climb, cover, vault, melee, animation-driven locomotion |
| Vehicles | 1 car, WheelCollider physics, damage → power loss, repair | Cars, bikes, sports cars, trucks, buses, boats, helicopters; visual deformation; tuning, paint, garages |
| World | Procedural block city, day/night | Hand-dressed streamed districts, weather (rain, storm, fog), interiors for shops/safehouses |
| Population | — | Traffic on lane graph, pedestrians with schedules, density scaled by platform |
| Missions | 1 linear tutorial | Data-driven mission graph (ScriptableObjects), checkpoints, fail states, cutscenes |
| UI | Menus, settings, HUD, minimap, map | Phone menu, waypoint routing, mission log, wardrobe/garage screens |
| Save | 1 JSON slot + backup | 3 slots + autosave, cloud save (optional, opt-in) |
| Audio | — | Original score, radio with original music, SFX, VO |

## 7. Controls

See the README controls table. Principles: every action reachable with one thumb per side; context buttons appear only when usable; full rebinding on PC; controller first-class on both platforms.

## 8. Technical direction

- **Engine:** Unity 6 LTS, URP (one pipeline for both platforms, quality tiers per device).
- **Streaming:** Addressables + additive scenes per tile; HLOD for distant skyline.
- **Population:** DOTS/Jobs for traffic & pedestrians once counts exceed ~150 agents.
- **Mobile budget (mid-range 2023 phone, 30 fps):** under 150 draw calls (SRP Batcher + GPU instancing), under 300k visible tris, 2 GB RAM ceiling, textures ASTC 6×6, one real-time shadow cascade.
- **PC tiers:** up to 4 cascades, higher LOD bias, 120 fps cap option, DLSS/FSR via URP upscaling where available.

## 9. Content & rating plan

| Content | Decision | Rating impact |
|---|---|---|
| Violence | Stylised, no gore, no killing of civilians required; police chases end with arrest/escape | Teen / PEGI 12–16 |
| Weapons | **Not in launch scope** (non-lethal tasers in a later update at most) | Keeps rating lower |
| Language | Mild | Teen |
| Drugs/alcohol | Referenced in story only, no use mechanics | Teen |
| Gambling | **None.** No loot boxes, no real-money casino | Avoids store restrictions |
| Monetisation | Premium on PC; on mobile, free demo + one-time unlock. No ads at launch | Simplifies Data Safety |

## 10. Art direction

"Golden-hour pop realism": saturated sunsets, pastel art-deco facades, palm silhouettes, wet neon at night. Realistic proportions and PBR materials, with a pushed colour grade. A modular building kit (facades, roofs, storefronts) lets a small team dress large areas.

## 11. Scope reality check

A GTA-scale game is built by teams of hundreds over many years. Port Solara reaches a strong result by:
- using a **smaller, denser map** instead of a huge empty one,
- building **kits and procedural tools** instead of hand-placing every prop,
- **buying** licensed marketplace art and animation packs (with commercial licences) for the vertical slice,
- shipping **Early Access** on PC and growing from there.

See the [Roadmap](Roadmap.md) for staffing and milestones.
