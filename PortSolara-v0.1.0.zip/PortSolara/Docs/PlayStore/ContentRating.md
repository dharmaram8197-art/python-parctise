# Content Rating, Data Safety & Policy Declarations

All of these are filled in **Play Console ▸ Policy ▸ App content**. Answer for the build you actually upload, and redo them whenever content changes.

## 1. Content rating (IARC questionnaire)
Category: **Game**. Expected answers for **v0.1**:

| Question area | v0.1 answer | Note for later versions |
|---|---|---|
| Violence | No violence (vehicle collisions with objects only) | Police chases/arrests or combat → answer "realistic violence" honestly; expect Teen/PEGI 12–16 |
| Blood / gore | No | Keep it "No" by design |
| Sexual content / nudity | No | |
| Profanity | No | Story VO may add mild language |
| Controlled substances | No | |
| Gambling / simulated gambling | No | Never add casino or loot boxes without re-rating |
| User interaction / chat | No | |
| Shares location | No | |
| Digital purchases | No | Yes once the unlock IAP exists |

Likely v0.1 result: Everyone / PEGI 3 to PEGI 7. **Don't inflate or deflate answers**; misrating can get the app removed.

## 2. Data safety form
| Question | Answer |
|---|---|
| Does your app collect or share any required user data types? | **No** |
| Is all user data encrypted in transit? | N/A (no data transmitted) |
| Do you provide a way to request data deletion? | N/A (no data collected; uninstall deletes local saves) |

Re-do this form before adding ads, analytics, Unity Gaming Services, Firebase or cloud saves. Most of those SDKs collect device IDs and diagnostics.

## 3. Other declarations
| Item | Answer |
|---|---|
| Privacy policy | URL of hosted `PrivacyPolicy.md` |
| Ads | **No ads** |
| App access | All functionality available without login |
| Target audience | **13+** (choosing under-13 brings in the Families policy and extra requirements) |
| News app | No |
| Government app | No |
| Financial features | No |
| Health | No |
| Data deletion URL | Not required (no accounts) |

## 4. Technical requirements checklist (verify in Play Console at upload time)
- [x] Android App Bundle (`.aab`) — `BuildScript` / CI
- [x] 64-bit (ARM64, IL2CPP) — `ProjectSetup`
- [x] Target API level **36** (required for new apps and updates since 31 Aug 2026) — `ProjectSetup`
- [ ] 16 KB memory page size support: use a current Unity 6 LTS patch and check the *App bundle explorer* warnings after upload
- [ ] Play App Signing enrolled; upload key stored safely and backed up
- [ ] Unique, final `applicationId` (can never change after publishing)
- [ ] `versionCode` increases with every upload (CI derives it from git tags)
- [ ] Closed testing track run before production if your developer account requires it

## 5. Intellectual property self-check
- [ ] No names, logos, characters, vehicles (real car brands are trademarks too), music or maps from other games or companies
- [ ] Store text and screenshots don't mention other franchises
- [ ] Every third-party asset has a licence that permits commercial use in a game; keep receipts and licence files in `Docs/Licenses/`
