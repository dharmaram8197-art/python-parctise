# Privacy Policy — Port Solara

*Last updated: [DATE]*

This policy describes how **[Studio / developer name]** ("we") handles information in the game **Port Solara** ("the App") on Android and Windows.

## Summary
The App does **not** collect, transmit, sell or share any personal data. It works fully offline.

## Data stored on your device
- **Save games** (player and vehicle position, vehicle condition, in-game time, mission progress) are stored locally in the App's private storage.
- **Settings and key bindings** are stored locally using the platform's preferences storage.
- **Screenshots** you take with F12 (Windows only) are saved locally.

This data never leaves your device. Uninstalling the App deletes it (Windows: delete the App's folder under `AppData\LocalLow`).

## Permissions
The Android build requests no dangerous permissions and does not request internet access.

## Third-party services
None. The App contains no advertising, analytics, crash-reporting or social SDKs. *(If any are added in future, this policy and the Play Data Safety form will be updated before release.)*

## Children
The App is not directed at children under 13 and we do not knowingly collect information from anyone.

## Changes
We will post any changes on this page and update the "Last updated" date.

## Contact
[support email] · [postal address if required in your jurisdiction]

---
*Developer note: before publishing, fill in the brackets, host this page at a public URL (e.g. GitHub Pages), and re-check it whenever you add an SDK (ads, analytics, Firebase, Unity Services, cloud save).*
