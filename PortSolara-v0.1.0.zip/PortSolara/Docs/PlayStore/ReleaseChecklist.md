# Release Checklist

## Android → Google Play
1. **Account:** Google Play Console developer account (one-time fee) and identity verification.
2. **App ID:** set the final `ApplicationId` in `ProjectSetup.cs`, then run *Tools ▸ Port Solara ▸ 2. Apply Recommended Player Settings*.
3. **Upload key:** Player Settings ▸ Publishing Settings ▸ Keystore Manager ▸ create `upload.keystore`. Back it up in two safe places. Never commit it.
4. **Build:** *Tools ▸ Port Solara ▸ Build ▸ Android App Bundle*, or push a `v0.1.0` tag and download the CI artifact (with keystore secrets configured).
5. **Test locally first:** build an APK, `adb install -r`, and run the manual plan in `Docs/Testing.md` on at least two phones.
6. **Play Console ▸ Create app:** name, default language, Game, Free.
7. **App content:** privacy policy, ads (no), app access, content rating, target audience (13+), data safety. See `ContentRating.md`.
8. **Store listing:** text from `StoreListing.md`, icon, feature graphic, real screenshots.
9. **Testing ▸ Internal testing:** upload the AAB, add testers, and fix pre-launch report crashes/ANRs.
10. **Closed testing:** run it if your account type requires it (check Play Console's current tester count and duration requirement).
11. **Production:** staged rollout (10% → 50% → 100%) while watching Android vitals (crash rate, ANR rate).

## Windows
1. *Tools ▸ Port Solara ▸ Build ▸ Windows (x64)* → `Builds/Windows/` (zip the **whole folder**: the `.exe`, `PortSolara_Data/`, `UnityPlayer.dll`, `MonoBleedingEdge/`).
2. Test on a clean Windows 10 and a Windows 11 PC (no Unity installed), with keyboard/mouse and an Xbox/PlayStation controller, at 1080p, 1440p and on a laptop with 125–150% scaling.
3. Distribution options: itch.io (fast, free), Steam (Steamworks fee, store page review), Microsoft Store (MSIX packaging).
4. Consider code-signing the executable to reduce SmartScreen warnings.

## Every release
- [ ] All CI tests green
- [ ] Version bumped (git tag `vX.Y.Z`)
- [ ] Manual test plan run on Windows **and** Android
- [ ] Changelog / release notes written
- [ ] Store text and screenshots still match the build
