# Google Play Store Listing (draft)

> Update this when real features ship. Play policy forbids describing features that aren't in the build, and forbids naming or comparing to other games/brands (e.g. no "like GTA").

**App name (≤30 chars):** `Port Solara`  *(11)*

**Short description (≤80 chars):**
`Drive a sunny coastal city, master your car and explore Port Solara.` *(68)*

**Full description (≤4000 chars) — accurate for v0.1 (Early Access / test track):**

```
Welcome to Port Solara, a sun-soaked coastal city waiting to be explored.

PORT SOLARA IS IN EARLY DEVELOPMENT. This test build contains the first playable slice; more districts, vehicles and story missions are coming.

WHAT'S IN THIS BUILD
• Explore an open city block grid, beach and seafront on foot or behind the wheel
• Drive a responsive sports coupe with handbrake slides and realistic damage
• Wreck it, tow it and get it repaired at the beachside garage
• Day and night cycle: watch the streetlights come on as the sun sets
• Swim in the sea
• Your first mission: "First Drive"
• Full touch controls with adjustable button size and opacity
• Bluetooth controller support
• Graphics, frame-rate and resolution settings to balance looks and battery life
• Save anywhere; progress autosaves when you leave the app

NO ADS. NO DATA COLLECTION. Plays fully offline.

We'd love your feedback. Tell us what to build next!
```

**Category:** Game ▸ Racing (switch to Action once combat/chases ship)
**Tags:** Driving, Open world, Racing, Offline
**Contact email:** *your support email (required)*
**Privacy policy URL:** *host `PrivacyPolicy.md` (e.g. GitHub Pages) and paste the URL*

## Graphics checklist
| Asset | Spec | File |
|---|---|---|
| App icon | 512×512 PNG, 32-bit, ≤1 MB | `graphics/icon-512.png` ✅ |
| Feature graphic | 1024×500 JPG/PNG, no alpha | `graphics/feature-graphic-1024x500.png` ✅ |
| Phone screenshots | 2–8, 16:9 landscape recommended (e.g. 1920×1080) | ⬜ capture from a real build |
| 7" & 10" tablet screenshots | Recommended so the game is promoted on tablets | ⬜ |

**How to capture honest screenshots:** run the Windows build at 1920×1080 and press **F12** (saved to `%USERPROFILE%\AppData\LocalLow\<Company>\Port Solara\Screenshots`), or use the phone's screenshot button. Suggested shots: sunset beach drive, downtown at night with lit lamps, car mid-drift, touch HUD with mission objective, full map. Screenshots must show real gameplay from the build you upload, with no mock-ups of unbuilt features.
