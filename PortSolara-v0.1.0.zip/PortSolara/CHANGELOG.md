# Changelog

## [0.1.0] — 2026-11-19 — Milestone 0: playable prototype
### Added
- Procedural coastal city (6×6 blocks), beach, sea, countryside, world bounds
- Day/night cycle with street lamps
- Third-person player: walk, sprint, jump, swim
- Drivable car: WheelCollider physics, damage, flip reset, flooding, tow, garage repair
- Input: keyboard/mouse (rebindable), gamepad, touch (joystick, look, contextual buttons)
- Menus: main, pause, settings, key bindings; HUD, minimap, full map
- Save/load (atomic JSON + backup), mobile autosave on background
- Tutorial mission "First Drive"
- Editor tooling (scene setup, player settings, builds), EditMode/PlayMode tests, GitHub Actions CI
- Game design document, architecture, roadmap, test plan, Google Play kit
