using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace PortSolara.Editor
{
    /// <summary>
    /// Command-line and menu builds for Windows (x64 .exe) and Android (.aab for Play, .apk for device testing).
    ///
    /// CI usage (game-ci/unity-builder): buildMethod: PortSolara.Editor.BuildScript.BuildFromCommandLine
    /// Recognised arguments: -buildTarget, -customBuildPath, -androidVersionCode, -androidExportType,
    /// -androidKeystoreName, -androidKeystorePass, -androidKeyaliasName, -androidKeyaliasPass.
    /// </summary>
    public static class BuildScript
    {
        [MenuItem("Tools/Port Solara/Build/Windows (x64)", priority = 20)]
        public static void BuildWindowsMenu() => BuildWindows("Builds/Windows/PortSolara.exe");

        [MenuItem("Tools/Port Solara/Build/Android APK (device testing)", priority = 21)]
        public static void BuildAndroidApkMenu() => BuildAndroid("Builds/Android/PortSolara.apk", appBundle: false, args: null);

        [MenuItem("Tools/Port Solara/Build/Android App Bundle (Google Play)", priority = 22)]
        public static void BuildAndroidAabMenu() => BuildAndroid("Builds/Android/PortSolara.aab", appBundle: true, args: null);

        /// <summary>Entry point for CI.</summary>
        public static void BuildFromCommandLine()
        {
            var args = ParseArgs();
            var target = EditorUserBuildSettings.activeBuildTarget;
            Debug.Log($"[BuildScript] Active build target: {target}");
            try
            {
                string buildVersion = Get(args, "buildVersion", "");
                if (!string.IsNullOrEmpty(buildVersion) && buildVersion != "none")
                    ProjectSetup.VersionOverride = buildVersion;   // e.g. 0.1.42 from git tags (GameCI "Semantic")

                switch (target)
                {
                    case BuildTarget.StandaloneWindows64:
                    case BuildTarget.StandaloneWindows:
                        BuildWindows(Get(args, "customBuildPath", "Builds/Windows/PortSolara.exe"));
                        break;
                    case BuildTarget.Android:
                        bool aab = Get(args, "androidExportType", "androidAppBundle") == "androidAppBundle";
                        BuildAndroid(Get(args, "customBuildPath", aab ? "Builds/Android/PortSolara.aab" : "Builds/Android/PortSolara.apk"), aab, args);
                        break;
                    default:
                        throw new BuildFailedException($"Unsupported build target {target}.");
                }
                ExitIfBatch(0);
            }
            catch (Exception e)
            {
                Debug.LogException(e);
                ExitIfBatch(1);
            }
        }

        public static void BuildWindows(string outputPath)
        {
            if (!ProjectSetup.EnsureMainScene(openIt: false)) throw new BuildFailedException("Build cancelled.");
            ProjectSetup.ApplyPlayerSettings();
            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Standalone, BuildTarget.StandaloneWindows64);
            Run(new BuildPlayerOptions
            {
                scenes = new[] { ProjectSetup.ScenePath },
                locationPathName = outputPath,
                target = BuildTarget.StandaloneWindows64,
                options = BuildOptions.None
            });
        }

        public static void BuildAndroid(string outputPath, bool appBundle, Dictionary<string, string> args)
        {
            int versionCode = 0;
            if (args != null && args.TryGetValue("androidVersionCode", out var vc)) int.TryParse(vc, out versionCode);

            if (!ProjectSetup.EnsureMainScene(openIt: false)) throw new BuildFailedException("Build cancelled.");
            ProjectSetup.ApplyPlayerSettings(versionCode);
            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
            EditorUserBuildSettings.buildAppBundle = appBundle;

            // Signing: Play requires an upload key. Without one we fall back to the debug key (fine for local testing only).
            string ks = args != null ? Get(args, "androidKeystoreName", "") : "";
            if (!string.IsNullOrEmpty(ks) && File.Exists(ks))
            {
                PlayerSettings.Android.useCustomKeystore = true;
                PlayerSettings.Android.keystoreName = Path.GetFullPath(ks);
                PlayerSettings.Android.keystorePass = Get(args, "androidKeystorePass", "");
                PlayerSettings.Android.keyaliasName = Get(args, "androidKeyaliasName", "");
                PlayerSettings.Android.keyaliasPass = Get(args, "androidKeyaliasPass", "");
                Debug.Log("[BuildScript] Signing with upload keystore.");
            }
            else if (!PlayerSettings.Android.useCustomKeystore)
            {
                Debug.LogWarning("[BuildScript] No keystore provided — build is debug-signed and CANNOT be uploaded to Google Play.");
            }

            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(outputPath)));
            Run(new BuildPlayerOptions
            {
                scenes = new[] { ProjectSetup.ScenePath },
                locationPathName = outputPath,
                target = BuildTarget.Android,
                options = BuildOptions.None
            });
        }

        static void Run(BuildPlayerOptions options)
        {
            var dir = Path.GetDirectoryName(Path.GetFullPath(options.locationPathName));
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);

            BuildReport report = BuildPipeline.BuildPlayer(options);
            var s = report.summary;
            Debug.Log($"[BuildScript] {s.platform}: {s.result} — {s.totalSize / (1024f * 1024f):0.0} MB, {s.totalErrors} errors, {s.totalWarnings} warnings, {s.totalTime}");
            if (s.result != BuildResult.Succeeded)
                throw new BuildFailedException($"Build failed: {s.result} ({s.totalErrors} errors). See the Editor log.");
        }

        static Dictionary<string, string> ParseArgs()
        {
            var result = new Dictionary<string, string>();
            var a = Environment.GetCommandLineArgs();
            for (int i = 0; i < a.Length; i++)
            {
                if (!a[i].StartsWith("-")) continue;
                string key = a[i].TrimStart('-');
                string value = i + 1 < a.Length && !a[i + 1].StartsWith("-") ? a[i + 1] : "";
                result[key] = value;
            }
            return result;
        }

        static string Get(Dictionary<string, string> args, string key, string fallback) =>
            args != null && args.TryGetValue(key, out var v) && !string.IsNullOrEmpty(v) ? v : fallback;

        static void ExitIfBatch(int code)
        {
            if (Application.isBatchMode) EditorApplication.Exit(code);
        }
    }
}
