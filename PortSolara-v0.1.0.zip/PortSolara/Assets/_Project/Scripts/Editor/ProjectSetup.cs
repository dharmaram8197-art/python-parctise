using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace PortSolara.Editor
{
    /// <summary>
    /// One-click project setup: creates the Main scene (containing the GameManager),
    /// registers it in Build Settings, and applies recommended Player Settings for
    /// Android (Google Play) and Windows. Safe to run repeatedly.
    /// </summary>
    public static class ProjectSetup
    {
        public const string ScenePath = "Assets/_Project/Scenes/Main.unity";

        // ⚠ Change these before your first Play Store upload — the application ID can never change afterwards.
        public const string CompanyName = "YourStudio";
        public const string ProductName = "Port Solara";
        public const string ApplicationId = "com.yourstudio.portsolara";
        public const string Version = "0.1.0";

        /// <summary>Set by CI to stamp the version computed from git tags.</summary>
        public static string VersionOverride;

        [MenuItem("Tools/Port Solara/1. Create or Repair Main Scene", priority = 1)]
        public static void CreateMainSceneMenu()
        {
            if (!EnsureMainScene(openIt: true)) return;
            EditorUtility.DisplayDialog("Port Solara", "Main scene is ready at\n" + ScenePath + "\n\nPress Play to run the prototype.", "OK");
        }

        [MenuItem("Tools/Port Solara/2. Apply Recommended Player Settings", priority = 2)]
        public static void ApplyPlayerSettingsMenu()
        {
            ApplyPlayerSettings();
            EditorUtility.DisplayDialog("Port Solara",
                "Player Settings applied.\n\nBefore publishing, change the Application ID in ProjectSetup.cs (currently " + ApplicationId + ").",
                "OK");
        }

        /// <summary>
        /// Creates the scene if missing, makes sure it contains a GameManager, and registers it in Build Settings.
        /// Returns false if the user cancelled saving their currently open scene.
        /// </summary>
        public static bool EnsureMainScene(bool openIt)
        {
            if (!Application.isBatchMode && !EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                return false;

            Directory.CreateDirectory(Path.GetDirectoryName(ScenePath));
            Scene scene = File.Exists(ScenePath)
                ? EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single)
                : EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            bool hasManager = scene.GetRootGameObjects().Any(root => root.GetComponentInChildren<GameManager>(true) != null);
            if (!hasManager)
            {
                var go = new GameObject("Game");
                SceneManager.MoveGameObjectToScene(go, scene);
                go.AddComponent<GameManager>();
            }

            EditorSceneManager.SaveScene(scene, ScenePath);

            var scenes = EditorBuildSettings.scenes.Where(entry => entry.path != ScenePath).ToList();
            scenes.Insert(0, new EditorBuildSettingsScene(ScenePath, true));
            EditorBuildSettings.scenes = scenes.ToArray();
            AssetDatabase.SaveAssets();
            return true;
        }

        public static void ApplyPlayerSettings(int androidVersionCode = 0)
        {
            PlayerSettings.companyName = CompanyName;
            PlayerSettings.productName = ProductName;
            PlayerSettings.bundleVersion = string.IsNullOrEmpty(VersionOverride) ? Version : VersionOverride;

            // Default icon for all platforms (Android adaptive icons can be added later in Player Settings).
            var icon = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/_Project/Art/Icons/AppIcon.png");
            if (icon != null) PlayerSettings.SetIcons(NamedBuildTarget.Unknown, new[] { icon }, IconKind.Any);
            else Debug.LogWarning("[PortSolara] App icon not found at Assets/_Project/Art/Icons/AppIcon.png");

            // Landscape only — the game is designed for it.
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;

            // ---------------- Android / Google Play ----------------
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, ApplicationId);
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP); // required for ARM64
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;                        // Play requires 64-bit
            PlayerSettings.Android.minSdkVersion = (AndroidSdkVersions)26;                                 // Android 8.0
            PlayerSettings.Android.targetSdkVersion = (AndroidSdkVersions)36;                              // Play: API 36 for new apps/updates since 31 Aug 2026
            if (androidVersionCode > 0) PlayerSettings.Android.bundleVersionCode = androidVersionCode;
            PlayerSettings.SetManagedStrippingLevel(NamedBuildTarget.Android, ManagedStrippingLevel.Low);
            PlayerSettings.Android.forceInternetPermission = false;                                        // game needs no network
            PlayerSettings.SetIl2CppCodeGeneration(NamedBuildTarget.Android, Il2CppCodeGeneration.OptimizeSize);
            EditorUserBuildSettings.buildAppBundle = true;

            // ---------------- Windows ----------------
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Standalone, ScriptingImplementation.Mono2x); // buildable from Linux CI
            PlayerSettings.fullScreenMode = FullScreenMode.FullScreenWindow;
            PlayerSettings.resizableWindow = true;
            PlayerSettings.runInBackground = true;

            AssetDatabase.SaveAssets();
            Debug.Log("[PortSolara] Player Settings applied.");
        }
    }
}
