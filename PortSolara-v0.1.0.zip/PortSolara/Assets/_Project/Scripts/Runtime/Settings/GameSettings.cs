using System;
using UnityEngine;

namespace PortSolara.Settings
{
    public enum TouchControlsMode { Auto = 0, On = 1, Off = 2 }

    /// <summary>
    /// Player-facing settings, persisted in PlayerPrefs and applied to the engine.
    /// Every value here is wired to a real engine setting or gameplay system.
    /// </summary>
    public static class GameSettings
    {
        public static event Action Changed;

        public static readonly int[] FrameRateOptions = { 30, 60, 120 };
        public static readonly float[] RenderScaleOptions = { 0.5f, 0.6f, 0.7f, 0.8f, 0.9f, 1.0f };
        public static readonly int[] DrawDistanceOptions = { 150, 250, 400, 600, 1000 };

        const string Prefix = "ps.settings.";

        public static int QualityLevel { get; set; }
        public static int FrameRateIndex { get; set; }
        public static int RenderScaleIndex { get; set; }
        public static int DrawDistanceIndex { get; set; }
        public static bool VSync { get; set; }
        public static bool Fullscreen { get; set; }
        public static float LookSensitivity { get; set; }
        public static bool InvertY { get; set; }
        public static TouchControlsMode TouchMode { get; set; }
        public static float TouchScale { get; set; }
        public static float TouchOpacity { get; set; }
        public static bool ShowMinimap { get; set; }

        public static int TargetFrameRate => FrameRateOptions[Mathf.Clamp(FrameRateIndex, 0, FrameRateOptions.Length - 1)];
        public static float RenderScale => RenderScaleOptions[Mathf.Clamp(RenderScaleIndex, 0, RenderScaleOptions.Length - 1)];
        public static float DrawDistance => DrawDistanceOptions[Mathf.Clamp(DrawDistanceIndex, 0, DrawDistanceOptions.Length - 1)];

        static bool _loaded;
        static int _nativeWidth, _nativeHeight;

        public static bool IsMobile => Application.isMobilePlatform;

        public static bool TouchControlsActive
        {
            get
            {
                switch (TouchMode)
                {
                    case TouchControlsMode.On: return true;
                    case TouchControlsMode.Off: return false;
                    default:
                        return Application.isMobilePlatform; // set "On" to test touch UI in the Editor or on touch PCs
                }
            }
        }

        public static void EnsureLoaded()
        {
            if (_loaded) return;
            Load();
        }

        public static void ResetToDefaults()
        {
            bool mobile = IsMobile;
            int qCount = Mathf.Max(1, QualitySettings.names.Length);
            QualityLevel = mobile ? Mathf.Clamp(qCount / 3, 0, qCount - 1) : qCount - 1 - (qCount > 2 ? 1 : 0);
            FrameRateIndex = mobile ? 0 : 1;          // 30 fps on mobile (battery), 60 on PC
            RenderScaleIndex = mobile ? 3 : 5;        // 80% on mobile, 100% on PC
            DrawDistanceIndex = mobile ? 1 : 3;
            VSync = true;
            Fullscreen = true;
            LookSensitivity = 1f;
            InvertY = false;
            TouchMode = TouchControlsMode.Auto;
            TouchScale = 1f;
            TouchOpacity = 0.6f;
            ShowMinimap = true;
        }

        public static void Load()
        {
            ResetToDefaults();
            QualityLevel = PlayerPrefs.GetInt(Prefix + "quality", QualityLevel);
            FrameRateIndex = PlayerPrefs.GetInt(Prefix + "fps", FrameRateIndex);
            RenderScaleIndex = PlayerPrefs.GetInt(Prefix + "renderScale", RenderScaleIndex);
            DrawDistanceIndex = PlayerPrefs.GetInt(Prefix + "drawDistance", DrawDistanceIndex);
            VSync = PlayerPrefs.GetInt(Prefix + "vsync", VSync ? 1 : 0) == 1;
            Fullscreen = PlayerPrefs.GetInt(Prefix + "fullscreen", Fullscreen ? 1 : 0) == 1;
            LookSensitivity = PlayerPrefs.GetFloat(Prefix + "lookSens", LookSensitivity);
            InvertY = PlayerPrefs.GetInt(Prefix + "invertY", InvertY ? 1 : 0) == 1;
            TouchMode = (TouchControlsMode)PlayerPrefs.GetInt(Prefix + "touchMode", (int)TouchMode);
            TouchScale = PlayerPrefs.GetFloat(Prefix + "touchScale", TouchScale);
            TouchOpacity = PlayerPrefs.GetFloat(Prefix + "touchOpacity", TouchOpacity);
            ShowMinimap = PlayerPrefs.GetInt(Prefix + "minimap", ShowMinimap ? 1 : 0) == 1;
            Sanitize();
            _loaded = true;
        }

        static void Sanitize()
        {
            QualityLevel = Mathf.Clamp(QualityLevel, 0, Mathf.Max(0, QualitySettings.names.Length - 1));
            FrameRateIndex = Mathf.Clamp(FrameRateIndex, 0, FrameRateOptions.Length - 1);
            RenderScaleIndex = Mathf.Clamp(RenderScaleIndex, 0, RenderScaleOptions.Length - 1);
            DrawDistanceIndex = Mathf.Clamp(DrawDistanceIndex, 0, DrawDistanceOptions.Length - 1);
            LookSensitivity = Mathf.Clamp(LookSensitivity, 0.2f, 3f);
            TouchScale = Mathf.Clamp(TouchScale, 0.7f, 1.5f);
            TouchOpacity = Mathf.Clamp(TouchOpacity, 0.2f, 1f);
            if (!Enum.IsDefined(typeof(TouchControlsMode), TouchMode)) TouchMode = TouchControlsMode.Auto;
        }

        public static void Save()
        {
            Sanitize();
            PlayerPrefs.SetInt(Prefix + "quality", QualityLevel);
            PlayerPrefs.SetInt(Prefix + "fps", FrameRateIndex);
            PlayerPrefs.SetInt(Prefix + "renderScale", RenderScaleIndex);
            PlayerPrefs.SetInt(Prefix + "drawDistance", DrawDistanceIndex);
            PlayerPrefs.SetInt(Prefix + "vsync", VSync ? 1 : 0);
            PlayerPrefs.SetInt(Prefix + "fullscreen", Fullscreen ? 1 : 0);
            PlayerPrefs.SetFloat(Prefix + "lookSens", LookSensitivity);
            PlayerPrefs.SetInt(Prefix + "invertY", InvertY ? 1 : 0);
            PlayerPrefs.SetInt(Prefix + "touchMode", (int)TouchMode);
            PlayerPrefs.SetFloat(Prefix + "touchScale", TouchScale);
            PlayerPrefs.SetFloat(Prefix + "touchOpacity", TouchOpacity);
            PlayerPrefs.SetInt(Prefix + "minimap", ShowMinimap ? 1 : 0);
            PlayerPrefs.Save();
        }

        /// <summary>Pushes the current values into the engine and notifies listeners.</summary>
        public static void Apply()
        {
            EnsureLoaded();
            Sanitize();

            if (QualitySettings.names.Length > 0)
                QualitySettings.SetQualityLevel(QualityLevel, true);

            if (IsMobile)
            {
                // Mobile: vSync is ignored by the OS; targetFrameRate controls pacing (and battery use).
                QualitySettings.vSyncCount = 0;
                Application.targetFrameRate = TargetFrameRate;
                ApplyMobileRenderScale();
            }
            else
            {
                QualitySettings.vSyncCount = VSync ? 1 : 0;
                Application.targetFrameRate = VSync ? -1 : TargetFrameRate;
                if (!Application.isEditor)
                {
                    var mode = Fullscreen ? FullScreenMode.FullScreenWindow : FullScreenMode.Windowed;
                    if (Screen.fullScreenMode != mode) Screen.fullScreenMode = mode;
                }
            }

            Changed?.Invoke();
        }

        static void ApplyMobileRenderScale()
        {
            if (_nativeWidth == 0)
            {
                _nativeWidth = Screen.width;
                _nativeHeight = Screen.height;
            }
            int w = Mathf.Max(320, Mathf.RoundToInt(_nativeWidth * RenderScale));
            int h = Mathf.Max(240, Mathf.RoundToInt(_nativeHeight * RenderScale));
            if (Screen.width != w || Screen.height != h)
                Screen.SetResolution(w, h, true);
        }

        public static string QualityName =>
            QualitySettings.names.Length == 0 ? "Default" : QualitySettings.names[Mathf.Clamp(QualityLevel, 0, QualitySettings.names.Length - 1)];
    }
}
