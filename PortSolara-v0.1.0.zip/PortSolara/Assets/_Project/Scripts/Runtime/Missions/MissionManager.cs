using System;
using PortSolara.Core;
using PortSolara.Vehicles;
using UnityEngine;

namespace PortSolara.Missions
{
    /// <summary>
    /// Prototype mission "First Drive": get in the car, drive through three checkpoints,
    /// then park at the repair garage. A deliberately small, linear state machine that
    /// proves the objective → marker → HUD → save pipeline before the real mission system.
    /// </summary>
    public class MissionManager : MonoBehaviour
    {
        public const string MissionName = "First Drive";

        public int Stage { get; private set; }
        public bool Completed { get; private set; }
        public event Action<string> Notification;

        Vector3[] _checkpoints;
        Vector3 _garage;
        Transform _marker;
        Func<bool> _isDriving;
        VehicleController _vehicle;

        const float CheckpointRadius = 7f;
        const float GarageRadius = 6f;

        int StageCount => 2 + _checkpoints.Length; // enter car + checkpoints + garage

        public void Init(Vector3[] checkpoints, Vector3 garage, VehicleController vehicle, Func<bool> isDriving)
        {
            _checkpoints = checkpoints;
            _garage = garage;
            _vehicle = vehicle;
            _isDriving = isDriving;

            var m = new GameObject("MissionMarker");
            m.transform.SetParent(transform, false);
            Primitives.Make(PrimitiveType.Cylinder, "Beam", m.transform, new Vector3(0, 15f, 0), new Vector3(3f, 15f, 3f), Quaternion.identity, new Color(1f, 0.8f, 0.1f), false);
            Primitives.Make(PrimitiveType.Cylinder, "Ring", m.transform, new Vector3(0, 0.05f, 0), new Vector3(CheckpointRadius * 2f, 0.05f, CheckpointRadius * 2f), Quaternion.identity, new Color(1f, 0.85f, 0.2f), false);
            _marker = m.transform;
            SetStage(0, false);
        }

        public string Objective
        {
            get
            {
                if (_checkpoints == null) return "";
                if (Completed) return "Free roam — explore Port Solara";
                if (Stage == 0) return "Get in the car";
                if (Stage <= _checkpoints.Length) return $"Drive through checkpoint {Stage}/{_checkpoints.Length}";
                return "Park at the repair garage (east side, by the beach)";
            }
        }

        public Vector3? CurrentTarget
        {
            get
            {
                if (Completed || _checkpoints == null || Stage == 0) return null;
                return Stage <= _checkpoints.Length ? _checkpoints[Stage - 1] : _garage;
            }
        }

        public void Restart() => SetStage(0, false);

        public void Restore(int stage, bool completed)
        {
            if (completed) { Completed = true; Stage = StageCount; UpdateMarker(); return; }
            SetStage(Mathf.Clamp(stage, 0, StageCount - 1), false);
        }

        void SetStage(int stage, bool announce)
        {
            Stage = stage;
            Completed = false;
            UpdateMarker();
            if (announce) Notification?.Invoke(Objective);
        }

        void UpdateMarker()
        {
            var target = CurrentTarget;
            if (_marker == null) return;
            _marker.gameObject.SetActive(target.HasValue);
            if (target.HasValue) _marker.position = target.Value;
        }

        void Update()
        {
            if (_checkpoints == null || Completed) return;

            if (Stage == 0)
            {
                if (_isDriving()) SetStage(1, true);
                return;
            }
            if (!_isDriving() || _vehicle == null) return; // objectives require the car

            Vector3 p = _vehicle.transform.position;
            Vector3 target = CurrentTarget ?? p;
            float dist = Vector2.Distance(new Vector2(p.x, p.z), new Vector2(target.x, target.z));

            if (Stage <= _checkpoints.Length)
            {
                if (dist < CheckpointRadius) SetStage(Stage + 1, true);
            }
            else if (dist < GarageRadius && _vehicle.SpeedMs < 2f)
            {
                Completed = true;
                Stage = StageCount;
                UpdateMarker();
                Notification?.Invoke($"Mission complete: {MissionName}! Your car is being repaired.");
            }
        }
    }
}
