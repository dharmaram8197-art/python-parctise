using PortSolara.Settings;
using UnityEngine;
using UnityEngine.InputSystem;

namespace PortSolara.Input
{
    /// <summary>A single frame of unified player input from all devices.</summary>
    public struct GameInput
    {
        public Vector2 Move;        // x = strafe/steer, y = forward/back (-1..1)
        public Vector2 Look;        // degrees this frame (x = yaw, y = pitch)
        public float Throttle;      // -1..1 (vehicle)
        public bool Sprint;         // held
        public bool Handbrake;      // held
        public bool JumpPressed;
        public bool InteractPressed;
        public bool PausePressed;
        public bool ResetPressed;
        public bool MapPressed;
        public bool LookActive;     // true if the player supplied look input this frame
    }

    /// <summary>
    /// Merges keyboard/mouse, gamepad and on-screen touch controls into one <see cref="GameInput"/>.
    /// Gameplay code reads <see cref="Current"/> and never touches devices directly,
    /// which keeps every system platform-agnostic.
    /// </summary>
    [DefaultExecutionOrder(-100)]
    public class InputRouter : MonoBehaviour
    {
        public static InputRouter Instance { get; private set; }
        public static GameInput Current => Instance != null ? Instance._current : default;

        /// <summary>When false, mouse movement is ignored (e.g. cursor unlocked in menus).</summary>
        public bool MouseLookEnabled { get; set; }

        GameInput _current;

        // ---- Touch state, written by on-screen controls ----
        Vector2 _touchMove;
        Vector2 _touchLookPixels;
        float _touchThrottle;
        bool _touchSprint, _touchHandbrake;
        bool _touchJump, _touchInteract, _touchPause, _touchReset, _touchMap;

        public void SetTouchMove(Vector2 v) => _touchMove = Vector2.ClampMagnitude(v, 1f);
        public void AddTouchLook(Vector2 pixels) => _touchLookPixels += pixels;
        public void SetTouchThrottle(float v) => _touchThrottle = Mathf.Clamp(v, -1f, 1f);
        public void SetTouchSprint(bool held) => _touchSprint = held;
        public void SetTouchHandbrake(bool held) => _touchHandbrake = held;
        public void PressTouchJump() => _touchJump = true;
        public void PressTouchInteract() => _touchInteract = true;
        public void PressTouchPause() => _touchPause = true;
        public void PressTouchReset() => _touchReset = true;
        public void PressTouchMap() => _touchMap = true;

        public void ClearTouchState()
        {
            _touchMove = Vector2.zero;
            _touchLookPixels = Vector2.zero;
            _touchThrottle = 0;
            _touchSprint = _touchHandbrake = false;
        }

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(this); return; }
            Instance = this;
        }

        void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        void Update()
        {
            var input = new GameInput();
            var bindings = KeyBindingsStore.Current;
            float sens = GameSettings.LookSensitivity;
            float invert = GameSettings.InvertY ? -1f : 1f;
            float dt = Time.unscaledDeltaTime;

            // ---------- Keyboard & mouse ----------
            var kb = Keyboard.current;
            if (kb != null)
            {
                float x = (Held(kb, bindings.Get(GameAction.MoveRight)) ? 1 : 0) - (Held(kb, bindings.Get(GameAction.MoveLeft)) ? 1 : 0);
                float y = (Held(kb, bindings.Get(GameAction.MoveForward)) ? 1 : 0) - (Held(kb, bindings.Get(GameAction.MoveBack)) ? 1 : 0);
                input.Move += new Vector2(x, y);
                input.Throttle += y;
                input.Sprint |= Held(kb, bindings.Get(GameAction.Sprint));
                input.Handbrake |= Held(kb, bindings.Get(GameAction.Handbrake));
                input.JumpPressed |= Pressed(kb, bindings.Get(GameAction.Jump));
                input.InteractPressed |= Pressed(kb, bindings.Get(GameAction.Interact));
                input.ResetPressed |= Pressed(kb, bindings.Get(GameAction.ResetVehicle));
                input.MapPressed |= Pressed(kb, bindings.Get(GameAction.ToggleMap));
                input.PausePressed |= kb.escapeKey.wasPressedThisFrame;
            }

            var mouse = Mouse.current;
            if (mouse != null && MouseLookEnabled)
            {
                Vector2 d = mouse.delta.ReadValue();
                if (d.sqrMagnitude > 0f)
                {
                    input.Look += new Vector2(d.x, d.y * invert) * (0.1f * sens);
                    input.LookActive = true;
                }
            }

            // ---------- Gamepad ----------
            var pad = Gamepad.current;
            if (pad != null)
            {
                Vector2 ls = ApplyDeadzone(pad.leftStick.ReadValue());
                input.Move += ls;
                Vector2 rs = ApplyDeadzone(pad.rightStick.ReadValue());
                if (rs.sqrMagnitude > 0f)
                {
                    input.Look += new Vector2(rs.x, rs.y * invert) * (160f * sens * dt);
                    input.LookActive = true;
                }
                float triggers = pad.rightTrigger.ReadValue() - pad.leftTrigger.ReadValue();
                input.Throttle += Mathf.Abs(triggers) > 0.05f ? triggers : ls.y;
                input.Sprint |= pad.leftStickButton.isPressed || pad.leftShoulder.isPressed;
                input.Handbrake |= pad.buttonSouth.isPressed || pad.rightShoulder.isPressed;
                input.JumpPressed |= pad.buttonSouth.wasPressedThisFrame;
                input.InteractPressed |= pad.buttonNorth.wasPressedThisFrame;
                input.ResetPressed |= pad.dpad.up.wasPressedThisFrame;
                input.MapPressed |= pad.selectButton.wasPressedThisFrame;
                input.PausePressed |= pad.startButton.wasPressedThisFrame;
            }

            // ---------- Touch (on-screen controls) ----------
            input.Move += _touchMove;
            input.Throttle += _touchThrottle;
            if (_touchLookPixels.sqrMagnitude > 0f)
            {
                // Normalise by screen height so the feel is the same on phones and tablets.
                float pxToDeg = 180f / Mathf.Max(1f, Screen.height);
                input.Look += new Vector2(_touchLookPixels.x, _touchLookPixels.y * invert) * (pxToDeg * sens);
                input.LookActive = true;
                _touchLookPixels = Vector2.zero;
            }
            input.Sprint |= _touchSprint;
            input.Handbrake |= _touchHandbrake;
            input.JumpPressed |= Consume(ref _touchJump);
            input.InteractPressed |= Consume(ref _touchInteract);
            input.PausePressed |= Consume(ref _touchPause);
            input.ResetPressed |= Consume(ref _touchReset);
            input.MapPressed |= Consume(ref _touchMap);

            input.Move = Vector2.ClampMagnitude(input.Move, 1f);
            input.Throttle = Mathf.Clamp(input.Throttle, -1f, 1f);
            _current = input;
        }

        static bool Consume(ref bool flag)
        {
            bool v = flag;
            flag = false;
            return v;
        }

        static Vector2 ApplyDeadzone(Vector2 v, float dz = 0.15f)
        {
            float m = v.magnitude;
            if (m < dz) return Vector2.zero;
            return v.normalized * Mathf.InverseLerp(dz, 1f, Mathf.Min(m, 1f));
        }

        static bool Held(Keyboard kb, Key key) => key != Key.None && kb[key].isPressed;
        static bool Pressed(Keyboard kb, Key key) => key != Key.None && kb[key].wasPressedThisFrame;
    }
}
