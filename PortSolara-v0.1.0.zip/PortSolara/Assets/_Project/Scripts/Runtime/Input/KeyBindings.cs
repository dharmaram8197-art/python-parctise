using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine.InputSystem;

namespace PortSolara.Input
{
    /// <summary>Rebindable keyboard actions. Pause is fixed to Escape so the player can never lock themselves out.</summary>
    public enum GameAction
    {
        MoveForward,
        MoveBack,
        MoveLeft,
        MoveRight,
        Jump,
        Sprint,
        Interact,
        Handbrake,
        ResetVehicle,
        ToggleMap
    }

    /// <summary>
    /// Keyboard bindings with (de)serialisation. Pure C# so it is unit-testable;
    /// persistence to PlayerPrefs lives in <see cref="KeyBindingsStore"/>.
    /// </summary>
    public class KeyBindings
    {
        readonly Dictionary<GameAction, Key> _map = new Dictionary<GameAction, Key>();

        public static readonly IReadOnlyDictionary<GameAction, Key> Defaults = new Dictionary<GameAction, Key>
        {
            { GameAction.MoveForward, Key.W },
            { GameAction.MoveBack, Key.S },
            { GameAction.MoveLeft, Key.A },
            { GameAction.MoveRight, Key.D },
            { GameAction.Jump, Key.Space },
            { GameAction.Sprint, Key.LeftShift },
            { GameAction.Interact, Key.F },
            { GameAction.Handbrake, Key.Space },
            { GameAction.ResetVehicle, Key.R },
            { GameAction.ToggleMap, Key.M },
        };

        public KeyBindings() { ResetToDefaults(); }

        public Key Get(GameAction action) => _map.TryGetValue(action, out var k) ? k : Defaults[action];

        /// <summary>Assigns a key. Escape and None are rejected (Escape is reserved for pause/cancel).</summary>
        public bool Set(GameAction action, Key key)
        {
            if (key == Key.None || key == Key.Escape) return false;
            _map[action] = key;
            return true;
        }

        public void ResetToDefaults()
        {
            _map.Clear();
            foreach (var kv in Defaults) _map[kv.Key] = kv.Value;
        }

        /// <summary>Format: "MoveForward=W;MoveBack=S;..."</summary>
        public string Serialize()
        {
            var sb = new StringBuilder();
            foreach (GameAction a in Enum.GetValues(typeof(GameAction)))
            {
                if (sb.Length > 0) sb.Append(';');
                sb.Append(a).Append('=').Append(Get(a));
            }
            return sb.ToString();
        }

        /// <summary>Parses serialized bindings. Unknown or invalid entries are ignored and keep their defaults.</summary>
        public static KeyBindings Parse(string data)
        {
            var kb = new KeyBindings();
            if (string.IsNullOrWhiteSpace(data)) return kb;
            foreach (var pair in data.Split(';'))
            {
                var parts = pair.Split('=');
                if (parts.Length != 2) continue;
                if (!Enum.TryParse(parts[0].Trim(), out GameAction action)) continue;
                if (!Enum.TryParse(parts[1].Trim(), out Key key)) continue;
                if (!Enum.IsDefined(typeof(GameAction), action) || !Enum.IsDefined(typeof(Key), key)) continue;
                kb.Set(action, key);
            }
            return kb;
        }

        public static string DisplayName(GameAction a)
        {
            switch (a)
            {
                case GameAction.MoveForward: return "Move Forward / Accelerate";
                case GameAction.MoveBack: return "Move Back / Brake-Reverse";
                case GameAction.MoveLeft: return "Move Left / Steer Left";
                case GameAction.MoveRight: return "Move Right / Steer Right";
                case GameAction.Jump: return "Jump";
                case GameAction.Sprint: return "Sprint";
                case GameAction.Interact: return "Enter / Exit Vehicle";
                case GameAction.Handbrake: return "Handbrake";
                case GameAction.ResetVehicle: return "Reset Vehicle";
                case GameAction.ToggleMap: return "Toggle Map";
                default: return a.ToString();
            }
        }
    }

    public static class KeyBindingsStore
    {
        const string PrefKey = "ps.keybindings";
        static KeyBindings _current;

        public static KeyBindings Current => _current ?? (_current = KeyBindings.Parse(UnityEngine.PlayerPrefs.GetString(PrefKey, "")));

        public static void Save()
        {
            UnityEngine.PlayerPrefs.SetString(PrefKey, Current.Serialize());
            UnityEngine.PlayerPrefs.Save();
        }
    }
}
