using UnityEngine;

namespace PortSolara.Core
{
    /// <summary>Small helpers for building placeholder geometry from Unity primitives.</summary>
    public static class Primitives
    {
        public static GameObject Box(string name, Transform parent, Vector3 center, Vector3 size, Color color, bool collider = true)
        {
            return Make(PrimitiveType.Cube, name, parent, center, size, Quaternion.identity, color, collider);
        }

        public static GameObject Make(PrimitiveType type, string name, Transform parent, Vector3 localPos, Vector3 scale,
            Quaternion localRot, Color color, bool collider)
        {
            var go = GameObject.CreatePrimitive(type);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            go.transform.localRotation = localRot;
            go.transform.localScale = scale;
            go.GetComponent<Renderer>().sharedMaterial = MaterialLibrary.Get(color);
            if (!collider)
            {
                var c = go.GetComponent<Collider>();
                if (c != null) Object.DestroyImmediate(c);
            }
            return go;
        }
    }
}
