using System.Collections.Generic;
using UnityEngine;

namespace PortSolara.Core
{
    /// <summary>
    /// Creates and caches flat-colour materials at runtime.
    /// Materials are cloned from the active render pipeline's default material
    /// (URP Lit or Built-in Standard), so the prototype works in either pipeline
    /// without shipping any material assets. Shared materials keep draw calls low
    /// and allow static batching.
    /// </summary>
    public static class MaterialLibrary
    {
        static Material _baseMaterial;
        static readonly Dictionary<Color32, Material> Cache = new Dictionary<Color32, Material>();

        static Material BaseMaterial
        {
            get
            {
                if (_baseMaterial == null)
                {
                    var probe = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    _baseMaterial = probe.GetComponent<Renderer>().sharedMaterial;
                    Object.DestroyImmediate(probe);
                }
                return _baseMaterial;
            }
        }

        /// <summary>Returns a shared material of the given colour.</summary>
        public static Material Get(Color color)
        {
            Color32 key = color;
            if (Cache.TryGetValue(key, out var mat) && mat != null) return mat;
            mat = CreateUnique(color);
            Cache[key] = mat;
            return mat;
        }

        /// <summary>Returns a new material instance (not shared) — use for objects whose colour changes.</summary>
        public static Material CreateUnique(Color color)
        {
            var mat = new Material(BaseMaterial) { color = color, enableInstancing = true };
            if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", color);
            if (mat.HasProperty("_Color")) mat.SetColor("_Color", color);
            if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", 0.2f);
            if (mat.HasProperty("_Glossiness")) mat.SetFloat("_Glossiness", 0.2f);
            return mat;
        }

        public static void SetColor(Material mat, Color color)
        {
            if (mat == null) return;
            mat.color = color;
            if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", color);
            if (mat.HasProperty("_Color")) mat.SetColor("_Color", color);
        }
    }
}
