using System;
using System.IO;
using PortSolara.CameraSystem;
using PortSolara.Input;
using PortSolara.Missions;
using PortSolara.Player;
using PortSolara.Save;
using PortSolara.Settings;
using PortSolara.UI;
using PortSolara.Vehicles;
using PortSolara.World;
using UnityEngine;
using UnityEngine.InputSystem;

namespace PortSolara
{
    public enum GameState { MainMenu, Playing, Paused }

    /// <summary>
    /// Composition root and game-flow state machine. Builds the world and every system at
    /// startup (no hidden scene wiring), then routes high-level input: pause, enter/exit
    /// vehicle, reset, map. Place one on an empty GameObject in the scene — or use
    /// Tools ▸ Port Solara ▸ Create Main Scene.
    /// </summary>
    [DefaultExecutionOrder(-50)]
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        [Tooltip("Seed for the procedural prototype city. Same seed → same city.")]
        public int citySeed = 1337;

        public GameState State { get; private set; } = GameState.MainMenu;
        public CityLayout Layout { get; private set; }
        public PlayerController Player { get; private set; }
        public VehicleController Vehicle { get; private set; }
        public ThirdPersonCamera Cam { get; private set; }
        public MissionManager Missions { get; private set; }
        public DayNightCycle DayNight { get; private set; }
        public RepairZone Repair { get; private set; }
        public GameUI UI { get; private set; }
        public bool IsDriving { get; private set; }
        public bool MapExpanded { get; private set; }

        public event Action<GameState> StateChanged;
        public event Action<string> Toast;

        public const float EnterVehicleRange = 3.5f;
        public const float MaxExitSpeed = 8f; // m/s

        Camera _mainCamera;

        // ------------------------------------------------------------------ setup

        void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Debug.LogWarning("[GameManager] Duplicate GameManager destroyed.");
                Destroy(gameObject);
                return;
            }
            Instance = this;
            Application.runInBackground = !Application.isMobilePlatform;
            GameSettings.EnsureLoaded();

            if (GetComponent<InputRouter>() == null) gameObject.AddComponent<InputRouter>();

            try
            {
                BuildWorld();
            }
            catch (Exception e)
            {
                // Surface build errors loudly instead of leaving a half-built, silent scene.
                Debug.LogException(e);
                throw;
            }

            GameSettings.Changed += ApplyViewSettings;
            GameSettings.Apply();
            SetState(GameState.MainMenu);
        }

        void OnDestroy()
        {
            GameSettings.Changed -= ApplyViewSettings;
            if (Instance == this)
            {
                Instance = null;
                Time.timeScale = 1f;
            }
        }

        void BuildWorld()
        {
            Layout = new CityLayout(citySeed);
            WorldQuery.Layout = Layout;

            var worldRoot = new GameObject("World").transform;
            var city = CityBuilder.Build(Layout, worldRoot);

            // Lighting
            var sun = FindSun();
            RenderSettings.sun = sun;
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;

            // Camera
            _mainCamera = Camera.main;
            if (_mainCamera == null)
            {
                var camGo = new GameObject("Main Camera") { tag = "MainCamera" };
                _mainCamera = camGo.AddComponent<Camera>();
                camGo.AddComponent<AudioListener>();
            }
            _mainCamera.nearClipPlane = 0.2f;
            _mainCamera.fieldOfView = 62f;
            if (RenderSettings.skybox == null) _mainCamera.clearFlags = CameraClearFlags.SolidColor;
            // Note: no '??' with UnityEngine.Object — the Editor returns "fake null" objects from GetComponent.
            Cam = _mainCamera.GetComponent<ThirdPersonCamera>();
            if (Cam == null) Cam = _mainCamera.gameObject.AddComponent<ThirdPersonCamera>();

            DayNight = sun.gameObject.GetComponent<DayNightCycle>();
            if (DayNight == null) DayNight = sun.gameObject.AddComponent<DayNightCycle>();
            DayNight.sun = sun;
            DayNight.targetCamera = _mainCamera;
            DayNight.RegisterLamps(city.LampHeads);

            // Actors
            Player = PlayerController.Create(Layout.PlayerSpawn, new Color(0.15f, 0.55f, 0.75f));
            Vehicle = VehicleController.Create(Layout.VehicleSpawn, Quaternion.identity, new Color(0.85f, 0.18f, 0.15f));
            Vehicle.Damaged += amount => { if (Vehicle.IsWrecked) RaiseToast("Your car is wrecked! Press Reset to tow it to the garage."); };

            Repair = RepairZone.Create(Layout.GaragePosition, Vehicle, worldRoot);

            var missionsGo = new GameObject("Missions");
            Missions = missionsGo.AddComponent<MissionManager>();
            Missions.Init(Layout.MissionCheckpoints, Layout.GaragePosition, Vehicle, () => IsDriving);
            Missions.Notification += RaiseToast;

            var uiGo = new GameObject("GameUI");
            UI = uiGo.AddComponent<GameUI>();
            UI.Init(this);
        }

        static Light FindSun()
        {
            foreach (var l in FindObjectsByType<Light>(FindObjectsSortMode.None))
                if (l.type == LightType.Directional) return l;
            var go = new GameObject("Sun");
            var sun = go.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.shadows = LightShadows.Soft;
            return sun;
        }

        void ApplyViewSettings()
        {
            if (_mainCamera == null) return;
            float d = GameSettings.DrawDistance;
            _mainCamera.farClipPlane = d;
            RenderSettings.fogStartDistance = d * 0.45f;
            RenderSettings.fogEndDistance = d * 0.98f;
        }

        // ------------------------------------------------------------------ game flow

        void SetState(GameState s)
        {
            State = s;
            Time.timeScale = s == GameState.Playing ? 1f : 0f;
            Screen.sleepTimeout = s == GameState.Playing ? SleepTimeout.NeverSleep : SleepTimeout.SystemSetting;
            if (s == GameState.MainMenu)
            {
                MapExpanded = false;
                Cam.SetMenu(Layout.Center, Mathf.Max(Layout.Width, Layout.Depth) * 0.55f);
            }
            UpdateCursor();
            StateChanged?.Invoke(s);
        }

        public void NewGame()
        {
            ResetWorldState();
            SetState(GameState.Playing);
            RaiseToast("Welcome to Port Solara. " + Missions.Objective + ".");
        }

        public bool ContinueGame(out string error)
        {
            if (!LoadGame(out error)) return false;
            SetState(GameState.Playing);
            return true;
        }

        public void Pause()
        {
            if (State == GameState.Playing) SetState(GameState.Paused);
        }

        public void Resume()
        {
            if (State == GameState.Paused) SetState(GameState.Playing);
        }

        public void ReturnToMainMenu() => SetState(GameState.MainMenu);

        public void RestartMission()
        {
            Missions.Restart();
            RaiseToast("Mission restarted: " + Missions.Objective);
        }

        public void QuitGame()
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }

        void ResetWorldState()
        {
            if (IsDriving) ForceExitVehicle(Layout.PlayerSpawn);
            Player.gameObject.SetActive(true);
            Player.Teleport(Layout.PlayerSpawn, 0f);
            Vehicle.Place(Layout.VehicleSpawn, Quaternion.identity);
            Vehicle.SetHealth(100f);
            Vehicle.HasDriver = false;
            DayNight.timeOfDay = 9f;
            DayNight.ApplyLighting();
            Missions.Restart();
            MapExpanded = false;
            Cam.Follow(Player.transform, ThirdPersonCamera.Mode.OnFoot);
        }

        // ------------------------------------------------------------------ save / load

        public bool SaveGame(out string message)
        {
            if (State == GameState.MainMenu) { message = "Nothing to save."; return false; }
            var data = new SaveData
            {
                playerPosition = Player.transform.position,
                playerYaw = Player.transform.eulerAngles.y,
                inVehicle = IsDriving,
                vehiclePosition = Vehicle.transform.position,
                vehicleRotation = Vehicle.transform.rotation,
                vehicleHealth = Vehicle.Health,
                timeOfDay = DayNight.timeOfDay,
                missionStage = Missions.Stage,
                missionCompleted = Missions.Completed
            };
            bool ok = SaveSystem.TrySave(data, out string error);
            message = ok ? "Game saved." : error;
            return ok;
        }

        public bool LoadGame(out string message)
        {
            if (!SaveSystem.TryLoad(out SaveData data, out string error))
            {
                message = error;
                return false;
            }

            if (IsDriving) ForceExitVehicle(data.playerPosition);
            Vehicle.Place(data.vehiclePosition + Vector3.up * 0.3f, data.vehicleRotation);
            Vehicle.SetHealth(data.vehicleHealth);
            DayNight.timeOfDay = Mathf.Repeat(data.timeOfDay, 24f);
            DayNight.ApplyLighting();
            Missions.Restore(data.missionStage, data.missionCompleted);
            MapExpanded = false;

            Player.gameObject.SetActive(true);
            Player.Teleport(data.playerPosition + Vector3.up * 0.1f, data.playerYaw);
            if (data.inVehicle) EnterVehicle();
            else Cam.Follow(Player.transform, ThirdPersonCamera.Mode.OnFoot);

            message = "Game loaded.";
            return true;
        }

        void OnApplicationPause(bool paused)
        {
            // Mobile: the OS may kill a backgrounded app, so pause and autosave.
            if (!paused || State != GameState.Playing) return;
            Pause();
            SaveGame(out _);
        }

        // ------------------------------------------------------------------ vehicles

        public bool CanEnterVehicle =>
            State == GameState.Playing && !IsDriving && Vehicle != null && Player != null &&
            Player.State != PlayerController.MoveState.Swimming &&
            Vector3.Distance(Player.transform.position, Vehicle.transform.position) < EnterVehicleRange;

        public void TryInteract()
        {
            if (IsDriving) TryExitVehicle();
            else if (CanEnterVehicle) EnterVehicle();
        }

        void EnterVehicle()
        {
            IsDriving = true;
            Vehicle.HasDriver = true;
            Player.gameObject.SetActive(false);
            Cam.Follow(Vehicle.transform, ThirdPersonCamera.Mode.Vehicle);
        }

        void TryExitVehicle()
        {
            if (Vehicle.SpeedMs > MaxExitSpeed)
            {
                RaiseToast("Slow down to get out.");
                return;
            }
            ForceExitVehicle(Vehicle.FindExitPoint(0.35f, 1.8f));
        }

        void ForceExitVehicle(Vector3 exitPoint)
        {
            IsDriving = false;
            Vehicle.HasDriver = false;
            Player.gameObject.SetActive(true);
            Player.Teleport(exitPoint, Vehicle.transform.eulerAngles.y);
            Cam.Follow(Player.transform, ThirdPersonCamera.Mode.OnFoot);
        }

        public void ResetVehicle()
        {
            if (!IsDriving) return;
            if (Vehicle.IsWrecked)
            {
                Vehicle.Place(Layout.GaragePosition + Vector3.up * 0.8f, Quaternion.Euler(0f, 90f, 0f));
                RaiseToast("Car towed to the garage. Stay on the blue pad to repair.");
                return;
            }
            if (Vehicle.SpeedMs > 5f)
            {
                RaiseToast("Stop the car before resetting.");
                return;
            }
            Vehicle.ResetUpright();
        }

        public string InteractionPrompt(bool touch)
        {
            if (State != GameState.Playing) return "";
            string pad = Gamepad.current != null ? " / (Y)" : "";
            string interactKey = KeyBindingsStore.Current.Get(GameAction.Interact).ToString();
            if (CanEnterVehicle) return touch ? "Tap ENTER to drive" : $"Press {interactKey}{pad} to drive";
            if (IsDriving && Vehicle.IsWrecked)
                return touch ? "Tap RESET to tow the car" : $"Press {KeyBindingsStore.Current.Get(GameAction.ResetVehicle)}{(Gamepad.current != null ? " / (D-pad Up)" : "")} to tow the car";
            if (IsDriving && Vehicle.IsFlooded) return touch ? "Tap EXIT to leave the car" : $"Press {interactKey}{pad} to get out";
            return "";
        }

        void RaiseToast(string message) => Toast?.Invoke(message);

        // ------------------------------------------------------------------ per-frame

        void Update()
        {
            var input = InputRouter.Current;
            bool padBack = Gamepad.current != null && Gamepad.current.buttonEast.wasPressedThisFrame;

            switch (State)
            {
                case GameState.Playing:
                    if (input.PausePressed) { Pause(); break; }
                    if (input.InteractPressed) TryInteract();
                    if (input.ResetPressed) ResetVehicle();
                    if (input.MapPressed) MapExpanded = !MapExpanded;
                    Player.ReferenceYaw = Cam.Yaw;
                    break;
                case GameState.Paused:
                case GameState.MainMenu:
                    if (input.PausePressed || padBack) UI.HandleBack();
                    break;
            }

            if (Keyboard.current != null && Keyboard.current.f12Key.wasPressedThisFrame) CaptureScreenshot();
            UpdateCursor();
        }

        void UpdateCursor()
        {
            bool lockCursor = State == GameState.Playing && !GameSettings.TouchControlsActive && Application.isFocused;
            var mode = lockCursor ? CursorLockMode.Locked : CursorLockMode.None;
            if (Cursor.lockState != mode) Cursor.lockState = mode;
            Cursor.visible = !lockCursor;
            if (InputRouter.Instance != null) InputRouter.Instance.MouseLookEnabled = lockCursor;
        }

        void CaptureScreenshot()
        {
            try
            {
                string dir = Path.Combine(Application.persistentDataPath, "Screenshots");
                Directory.CreateDirectory(dir);
                string path = Path.Combine(dir, $"PortSolara_{DateTime.Now:yyyyMMdd_HHmmss}.png");
                ScreenCapture.CaptureScreenshot(path);
                RaiseToast("Screenshot saved: " + path);
            }
            catch (Exception e)
            {
                Debug.LogWarning("[GameManager] Screenshot failed: " + e.Message);
            }
        }
    }
}
