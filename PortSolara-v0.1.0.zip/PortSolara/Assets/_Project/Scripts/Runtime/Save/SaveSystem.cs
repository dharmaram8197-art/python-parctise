using System;
using System.IO;
using UnityEngine;

namespace PortSolara.Save
{
    [Serializable]
    public class SaveData
    {
        public const int CurrentVersion = 1;

        public int version = CurrentVersion;
        public string savedAtUtc;
        public Vector3 playerPosition;
        public float playerYaw;
        public bool inVehicle;
        public Vector3 vehiclePosition;
        public Quaternion vehicleRotation = Quaternion.identity;
        public float vehicleHealth = 100f;
        public float timeOfDay = 9f;
        public int missionStage;
        public bool missionCompleted;

        /// <summary>Rejects data that would put the game in a broken state.</summary>
        public bool IsValid(out string reason)
        {
            if (version < 1 || version > CurrentVersion) { reason = $"Unsupported save version {version}."; return false; }
            if (!Finite(playerPosition) || !Finite(vehiclePosition)) { reason = "Save contains invalid positions."; return false; }
            if (float.IsNaN(vehicleRotation.x) || float.IsNaN(vehicleRotation.w)) { reason = "Save contains invalid rotation."; return false; }
            reason = null;
            return true;
        }

        static bool Finite(Vector3 v) => !(float.IsNaN(v.x) || float.IsNaN(v.y) || float.IsNaN(v.z) ||
                                           float.IsInfinity(v.x) || float.IsInfinity(v.y) || float.IsInfinity(v.z));
    }

    /// <summary>
    /// JSON save files in Application.persistentDataPath with atomic writes and a backup copy,
    /// so a crash or power loss mid-save (common on phones) never destroys the player's progress.
    /// </summary>
    public static class SaveSystem
    {
        static string _directoryOverride;

        /// <summary>Override the save folder (used by tests).</summary>
        public static string Directory
        {
            get => _directoryOverride ?? Application.persistentDataPath;
            set => _directoryOverride = value;
        }

        public static string SlotPath(int slot = 1) => Path.Combine(Directory, $"save_slot{slot}.json");
        static string BackupPath(int slot) => SlotPath(slot) + ".bak";
        static string TempPath(int slot) => SlotPath(slot) + ".tmp";

        public static bool HasSave(int slot = 1) => File.Exists(SlotPath(slot)) || File.Exists(BackupPath(slot));

        public static string Serialize(SaveData data) => JsonUtility.ToJson(data, true);

        public static bool TryDeserialize(string json, out SaveData data, out string error)
        {
            data = null;
            if (string.IsNullOrWhiteSpace(json)) { error = "Save file is empty."; return false; }
            try
            {
                data = JsonUtility.FromJson<SaveData>(json);
            }
            catch (Exception e)
            {
                error = "Save file is corrupted: " + e.Message;
                return false;
            }
            if (data == null) { error = "Save file is corrupted."; return false; }
            return data.IsValid(out error);
        }

        public static bool TrySave(SaveData data, out string error, int slot = 1)
        {
            try
            {
                System.IO.Directory.CreateDirectory(Directory);
                data.version = SaveData.CurrentVersion;
                data.savedAtUtc = DateTime.UtcNow.ToString("o");
                string json = Serialize(data);
                string path = SlotPath(slot), tmp = TempPath(slot), bak = BackupPath(slot);

                File.WriteAllText(tmp, json);
                if (File.Exists(path))
                {
                    if (File.Exists(bak)) File.Delete(bak);
                    File.Move(path, bak);
                }
                File.Move(tmp, path);
                error = null;
                return true;
            }
            catch (Exception e)
            {
                error = "Could not save: " + e.Message;
                Debug.LogError("[SaveSystem] " + error);
                return false;
            }
        }

        /// <summary>Loads the slot; falls back to the backup if the main file is missing or corrupted.</summary>
        public static bool TryLoad(out SaveData data, out string error, int slot = 1)
        {
            data = null;
            error = "No save found.";
            foreach (var path in new[] { SlotPath(slot), BackupPath(slot) })
            {
                try
                {
                    if (!File.Exists(path)) continue;
                    if (TryDeserialize(File.ReadAllText(path), out data, out error)) return true;
                    Debug.LogWarning($"[SaveSystem] {path}: {error}");
                }
                catch (Exception e)
                {
                    error = "Could not read save: " + e.Message;
                    Debug.LogWarning("[SaveSystem] " + error);
                }
            }
            data = null;
            return false;
        }

        public static void Delete(int slot = 1)
        {
            foreach (var p in new[] { SlotPath(slot), BackupPath(slot), TempPath(slot) })
                if (File.Exists(p)) File.Delete(p);
        }
    }
}
