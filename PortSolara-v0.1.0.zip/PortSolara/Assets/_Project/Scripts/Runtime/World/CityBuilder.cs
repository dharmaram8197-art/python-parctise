using System.Collections.Generic;
using PortSolara.Core;
using UnityEngine;

namespace PortSolara.World
{
    /// <summary>
    /// Turns a <see cref="CityLayout"/> into GameObjects using placeholder primitives.
    /// Geometry shares a small material palette and is static-batched, which keeps
    /// draw calls low enough for mid-range Android devices.
    /// Replace the primitive calls with prefab instantiation when real art arrives.
    /// </summary>
    public static class CityBuilder
    {
        static readonly Color Asphalt = new Color(0.16f, 0.16f, 0.18f);
        static readonly Color Sidewalk = new Color(0.55f, 0.54f, 0.52f);
        static readonly Color Grass = new Color(0.28f, 0.45f, 0.22f);
        static readonly Color Sand = new Color(0.86f, 0.78f, 0.58f);
        static readonly Color Water = new Color(0.10f, 0.42f, 0.58f);
        static readonly Color LaneMark = new Color(0.92f, 0.92f, 0.85f);
        static readonly Color Trunk = new Color(0.36f, 0.25f, 0.16f);
        static readonly Color Leaves = new Color(0.20f, 0.42f, 0.18f);
        static readonly Color Pole = new Color(0.25f, 0.26f, 0.28f);

        public static readonly Color[] BuildingPalette =
        {
            new Color(0.82f, 0.78f, 0.70f), new Color(0.62f, 0.66f, 0.72f), new Color(0.90f, 0.86f, 0.80f),
            new Color(0.70f, 0.55f, 0.45f), new Color(0.45f, 0.52f, 0.60f), new Color(0.95f, 0.75f, 0.60f),
            new Color(0.55f, 0.70f, 0.72f), new Color(0.78f, 0.62f, 0.70f)
        };

        public class Result
        {
            public GameObject Root;
            public readonly List<Renderer> LampHeads = new List<Renderer>();
            public GameObject Garage;
        }

        public static Result Build(CityLayout layout, Transform parent = null)
        {
            var result = new Result();
            var root = new GameObject("City");
            if (parent != null) root.transform.SetParent(parent, false);
            result.Root = root;
            var t = root.transform;

            var groundGroup = new GameObject("Ground").transform; groundGroup.SetParent(t, false);
            var roadsGroup = new GameObject("Roads").transform; roadsGroup.SetParent(t, false);
            var blocksGroup = new GameObject("Blocks").transform; blocksGroup.SetParent(t, false);
            var propsGroup = new GameObject("Props").transform; propsGroup.SetParent(t, false);

            float W = layout.Width, D = layout.Depth;

            // --- Countryside grass (everything west of the beach slope) ---
            const float far = 700f;
            float grassMaxX = layout.SlopeStartX;
            float grassMinX = -far;
            Primitives.Box("Grass", groundGroup,
                new Vector3((grassMinX + grassMaxX) * 0.5f, -0.5f, D * 0.5f),
                new Vector3(grassMaxX - grassMinX, 1f, D + far * 2f), Grass);

            // --- City asphalt (roads are the gaps between raised blocks) ---
            Primitives.Box("CityAsphalt", roadsGroup, new Vector3(W * 0.5f, -0.48f, D * 0.5f), new Vector3(W, 1f, D), Asphalt);

            // --- Beach flat sand + slope + sea floor + water surface ---
            Primitives.Box("BeachSand", groundGroup,
                new Vector3(layout.BeachStartX + CityLayout.BeachFlatWidth * 0.5f, -0.47f, D * 0.5f),
                new Vector3(CityLayout.BeachFlatWidth, 1f, D + far * 2f), Sand);

            float angle = Mathf.Atan2(CityLayout.SeaDepth, CityLayout.BeachSlopeLength);
            float slopeLen = Mathf.Sqrt(CityLayout.SeaDepth * CityLayout.SeaDepth + CityLayout.BeachSlopeLength * CityLayout.BeachSlopeLength);
            var topCenter = new Vector3(layout.SlopeStartX + CityLayout.BeachSlopeLength * 0.5f, -CityLayout.SeaDepth * 0.5f, D * 0.5f);
            var normal = new Vector3(Mathf.Sin(angle), Mathf.Cos(angle), 0f);
            var slope = Primitives.Box("BeachSlope", groundGroup, topCenter - normal * 0.5f, new Vector3(slopeLen, 1f, D + far * 2f), Sand);
            slope.transform.localRotation = Quaternion.Euler(0f, 0f, -angle * Mathf.Rad2Deg);

            Primitives.Box("SeaFloor", groundGroup,
                new Vector3(layout.SeaStartX + CityLayout.SeaLength * 0.5f, -CityLayout.SeaDepth - 0.5f, D * 0.5f),
                new Vector3(CityLayout.SeaLength, 1f, D + far * 2f), new Color(0.55f, 0.50f, 0.38f));

            float waterEdgeX = layout.SlopeStartX + CityLayout.BeachSlopeLength * (-CityLayout.WaterLevel / CityLayout.SeaDepth);
            float waterLen = layout.SeaStartX + CityLayout.SeaLength - waterEdgeX;
            Primitives.Box("WaterSurface", groundGroup,
                new Vector3(waterEdgeX + waterLen * 0.5f, CityLayout.WaterLevel - 0.05f, D * 0.5f),
                new Vector3(waterLen, 0.1f, D + far * 2f), Water, collider: false);

            // --- Blocks: raised sidewalks, buildings, parks ---
            for (int bx = 0; bx < layout.BlocksX; bx++)
            {
                for (int bz = 0; bz < layout.BlocksZ; bz++)
                {
                    float minX = layout.BlockMin(bx), minZ = layout.BlockMin(bz);
                    float h = CityLayout.SidewalkHeight;
                    Primitives.Box($"Block_{bx}_{bz}", blocksGroup,
                        new Vector3(minX + layout.BlockSize * 0.5f, h - 0.5f, minZ + layout.BlockSize * 0.5f),
                        new Vector3(layout.BlockSize, 1f, layout.BlockSize), Sidewalk);
                }
            }

            foreach (var lot in layout.Lots)
            {
                if (lot.Kind == LotKind.Park)
                {
                    Primitives.Box("ParkLawn", blocksGroup, lot.Center + new Vector3(0, 0.01f, 0),
                        new Vector3(lot.Size.x, 0.02f, lot.Size.y), Grass, collider: false);
                    // Four trees per park lot, deterministic positions.
                    for (int i = 0; i < 4; i++)
                    {
                        float ox = (i % 2 == 0 ? -1 : 1) * lot.Size.x * 0.25f;
                        float oz = (i < 2 ? -1 : 1) * lot.Size.y * 0.25f;
                        Tree(propsGroup, lot.Center + new Vector3(ox, 0f, oz));
                    }
                }
            }

            for (int i = 0; i < layout.Buildings.Count; i++)
            {
                var b = layout.Buildings[i];
                var color = BuildingPalette[b.ColorIndex % BuildingPalette.Length];
                var go = Primitives.Box($"Building_{i}", blocksGroup, b.Center, b.Size, color);
                // Simple roof cap for silhouette variety.
                if (b.Size.y > 20f)
                {
                    Primitives.Box("RoofCap", go.transform, new Vector3(0f, 0.5f + 1.5f / b.Size.y, 0f),
                        new Vector3(0.5f, 3f / b.Size.y, 0.5f), color * 0.85f, collider: false);
                }
            }

            // --- Lane markings (visual only) ---
            for (int ix = 0; ix <= layout.BlocksX; ix++)
            {
                float x = layout.RoadCenter(ix);
                Primitives.Box("LaneZ", roadsGroup, new Vector3(x, 0.025f, D * 0.5f), new Vector3(0.18f, 0.02f, D - layout.RoadWidth), LaneMark, collider: false);
            }
            for (int iz = 0; iz <= layout.BlocksZ; iz++)
            {
                float z = layout.RoadCenter(iz);
                Primitives.Box("LaneX", roadsGroup, new Vector3(W * 0.5f, 0.025f, z), new Vector3(W - layout.RoadWidth, 0.02f, 0.18f), LaneMark, collider: false);
            }

            // --- Street lamps at every intersection corner (one per intersection to save draw calls) ---
            foreach (var p in layout.Intersections)
            {
                var pos = p + new Vector3(layout.RoadWidth * 0.5f + 1f, CityLayout.SidewalkHeight, layout.RoadWidth * 0.5f + 1f);
                if (pos.x > W || pos.z > D) continue;
                Primitives.Make(PrimitiveType.Cylinder, "LampPole", propsGroup, pos + new Vector3(0, 3f, 0), new Vector3(0.18f, 3f, 0.18f), Quaternion.identity, Pole, true);
                var head = Primitives.Make(PrimitiveType.Sphere, "LampHead", propsGroup, pos + new Vector3(0, 6.2f, 0), Vector3.one * 0.6f, Quaternion.identity, new Color(0.6f, 0.6f, 0.55f), false);
                result.LampHeads.Add(head.GetComponent<Renderer>());
            }

            // --- Garage / repair shop on the beach side ---
            var garage = new GameObject("RepairGarage");
            garage.transform.SetParent(t, false);
            garage.transform.position = layout.GaragePosition;
            Primitives.Box("GarageBuilding", garage.transform, new Vector3(16f, 3.5f, 0f), new Vector3(12f, 7f, 14f), new Color(0.75f, 0.35f, 0.25f));
            Primitives.Box("GarageSign", garage.transform, new Vector3(9.9f, 6.2f, 0f), new Vector3(0.2f, 1.2f, 8f), new Color(1f, 0.85f, 0.2f), collider: false);
            result.Garage = garage;

            // --- World bounds (invisible walls) ---
            var bounds = new GameObject("WorldBounds").transform; bounds.SetParent(t, false);
            float maxX = layout.SeaStartX + CityLayout.SeaLength;
            Wall(bounds, new Vector3((grassMinX + maxX) * 0.5f, 25f, -far + D * 0.5f), new Vector3(maxX - grassMinX, 60f, 2f));
            Wall(bounds, new Vector3((grassMinX + maxX) * 0.5f, 25f, far + D * 0.5f), new Vector3(maxX - grassMinX, 60f, 2f));
            Wall(bounds, new Vector3(grassMinX, 25f, D * 0.5f), new Vector3(2f, 60f, far * 2f));
            Wall(bounds, new Vector3(maxX, 25f, D * 0.5f), new Vector3(2f, 60f, far * 2f));

            // Static batching: combine everything except lamp heads (their colour changes at night).
            foreach (var r in result.LampHeads) r.transform.SetParent(t, true);
            StaticBatchingUtility.Combine(groundGroup.gameObject);
            StaticBatchingUtility.Combine(roadsGroup.gameObject);
            StaticBatchingUtility.Combine(blocksGroup.gameObject);
            StaticBatchingUtility.Combine(propsGroup.gameObject);

            return result;
        }

        static void Tree(Transform parent, Vector3 basePos)
        {
            Primitives.Make(PrimitiveType.Cylinder, "Trunk", parent, basePos + new Vector3(0, 1.5f, 0), new Vector3(0.35f, 1.5f, 0.35f), Quaternion.identity, Trunk, true);
            Primitives.Make(PrimitiveType.Sphere, "Canopy", parent, basePos + new Vector3(0, 4f, 0), new Vector3(3.2f, 3f, 3.2f), Quaternion.identity, Leaves, false);
        }

        static void Wall(Transform parent, Vector3 center, Vector3 size)
        {
            var go = new GameObject("Wall");
            go.transform.SetParent(parent, false);
            go.transform.position = center;
            var bc = go.AddComponent<BoxCollider>();
            bc.size = size;
        }
    }
}
