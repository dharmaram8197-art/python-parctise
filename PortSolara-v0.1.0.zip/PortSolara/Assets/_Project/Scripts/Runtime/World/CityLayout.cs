using System;
using System.Collections.Generic;
using UnityEngine;

namespace PortSolara.World
{
    public enum LotKind { Building, Park, Plaza }

    [Serializable]
    public struct BuildingSpec
    {
        public Vector3 Center;   // world centre of the box
        public Vector3 Size;
        public int ColorIndex;
    }

    [Serializable]
    public struct LotSpec
    {
        public Vector3 Center;   // ground-level centre
        public Vector2 Size;
        public LotKind Kind;
    }

    /// <summary>
    /// Deterministic, engine-independent description of the prototype city ("Port Solara – Old Town").
    /// Generating data separately from GameObjects lets us unit-test the layout and,
    /// later, stream districts in and out.
    /// Coordinates: city grid starts at (0,0) and extends along +X / +Z. The beach and sea are on +X.
    /// </summary>
    public class CityLayout
    {
        public readonly int Seed;
        public readonly int BlocksX;
        public readonly int BlocksZ;
        public readonly float BlockSize;
        public readonly float RoadWidth;

        public const float SidewalkHeight = 0.18f;
        public const float BeachFlatWidth = 25f;
        public const float BeachSlopeLength = 30f;
        public const float SeaDepth = 4f;
        public const float WaterLevel = -1.2f;
        public const float SeaLength = 160f;

        public readonly List<BuildingSpec> Buildings = new List<BuildingSpec>();
        public readonly List<LotSpec> Lots = new List<LotSpec>();
        public readonly List<Vector3> Intersections = new List<Vector3>();

        public float Cell => BlockSize + RoadWidth;
        /// <summary>Total size of the road grid including the outer ring road.</summary>
        public float Width => BlocksX * Cell + RoadWidth;
        public float Depth => BlocksZ * Cell + RoadWidth;
        public Vector3 Center => new Vector3(Width * 0.5f, 0f, Depth * 0.5f);
        public float BeachStartX => Width;
        public float SlopeStartX => Width + BeachFlatWidth;
        public float SeaStartX => SlopeStartX + BeachSlopeLength;

        public Vector3 PlayerSpawn { get; private set; }
        public Vector3 VehicleSpawn { get; private set; }
        public Vector3 GaragePosition { get; private set; }
        public Vector3[] MissionCheckpoints { get; private set; }

        public CityLayout(int seed = 1337, int blocksX = 6, int blocksZ = 6, float blockSize = 44f, float roadWidth = 12f)
        {
            if (blocksX < 2 || blocksZ < 2) throw new ArgumentException("City needs at least 2x2 blocks.");
            Seed = seed;
            BlocksX = blocksX;
            BlocksZ = blocksZ;
            BlockSize = blockSize;
            RoadWidth = roadWidth;
            Generate();
        }

        /// <summary>Road centre-line X (or Z) for road index i (0..Blocks).</summary>
        public float RoadCenter(int i) => i * Cell + RoadWidth * 0.5f;

        /// <summary>Block min corner along an axis.</summary>
        public float BlockMin(int i) => i * Cell + RoadWidth;

        void Generate()
        {
            var rng = new System.Random(Seed);

            for (int ix = 0; ix <= BlocksX; ix++)
                for (int iz = 0; iz <= BlocksZ; iz++)
                    Intersections.Add(new Vector3(RoadCenter(ix), 0f, RoadCenter(iz)));

            float cx = (BlocksX - 1) * 0.5f, cz = (BlocksZ - 1) * 0.5f;
            float maxDist = Mathf.Sqrt(cx * cx + cz * cz);
            const float lotMargin = 3f; // sidewalk around buildings

            for (int bx = 0; bx < BlocksX; bx++)
            {
                for (int bz = 0; bz < BlocksZ; bz++)
                {
                    float minX = BlockMin(bx), minZ = BlockMin(bz);
                    // One park block in the centre-ish and one near the beach.
                    bool parkBlock = (bx == BlocksX / 2 - 1 && bz == BlocksZ / 2) || (bx == BlocksX - 1 && bz == 1);
                    float d = Mathf.Sqrt((bx - cx) * (bx - cx) + (bz - cz) * (bz - cz)) / Mathf.Max(0.01f, maxDist);
                    float downtown = 1f - d; // 1 at centre, 0 at edge

                    float lot = (BlockSize - lotMargin * 3f) * 0.5f;
                    for (int lx = 0; lx < 2; lx++)
                    {
                        for (int lz = 0; lz < 2; lz++)
                        {
                            float lotMinX = minX + lotMargin + lx * (lot + lotMargin);
                            float lotMinZ = minZ + lotMargin + lz * (lot + lotMargin);
                            var lotCenter = new Vector3(lotMinX + lot * 0.5f, SidewalkHeight, lotMinZ + lot * 0.5f);

                            LotKind kind;
                            if (parkBlock) kind = LotKind.Park;
                            else
                            {
                                double r = rng.NextDouble();
                                kind = r < 0.08 ? LotKind.Plaza : r < 0.16 ? LotKind.Park : LotKind.Building;
                            }
                            Lots.Add(new LotSpec { Center = lotCenter, Size = new Vector2(lot, lot), Kind = kind });
                            if (kind != LotKind.Building) continue;

                            float minH = Mathf.Lerp(6f, 18f, downtown);
                            float maxH = Mathf.Lerp(14f, 75f, downtown * downtown);
                            float h = Mathf.Lerp(minH, maxH, (float)rng.NextDouble());
                            float shrink = (float)(rng.NextDouble() * 4.0);
                            float sx = lot - shrink, sz = lot - (float)(rng.NextDouble() * 4.0);
                            Buildings.Add(new BuildingSpec
                            {
                                Center = new Vector3(lotCenter.x, SidewalkHeight + h * 0.5f, lotCenter.z),
                                Size = new Vector3(sx, h, sz),
                                ColorIndex = rng.Next(0, 8)
                            });
                        }
                    }
                }
            }

            // Spawn on the road next to the centre intersection; car parked just ahead.
            var c = new Vector3(RoadCenter(BlocksX / 2), 0f, RoadCenter(BlocksZ / 2));
            PlayerSpawn = c + new Vector3(-3f, 0.1f, 8f);
            VehicleSpawn = c + new Vector3(2.5f, 0.6f, 12f);

            // Garage sits on the beach-side road (outer ring, east edge).
            GaragePosition = new Vector3(RoadCenter(BlocksX), 0f, RoadCenter(1) + Cell * 0.5f);

            MissionCheckpoints = new[]
            {
                new Vector3(RoadCenter(BlocksX / 2), 0f, RoadCenter(BlocksZ)),        // north ring road
                new Vector3(RoadCenter(0), 0f, RoadCenter(BlocksZ)),                  // north-west corner
                new Vector3(RoadCenter(0), 0f, RoadCenter(0)),                        // south-west corner
            };
        }

        /// <summary>True if a world XZ point lies on a road surface.</summary>
        public bool IsOnRoad(Vector3 p)
        {
            if (p.x < 0 || p.z < 0 || p.x > Width || p.z > Depth) return false;
            float mx = Mod(p.x, Cell), mz = Mod(p.z, Cell);
            return mx < RoadWidth || mz < RoadWidth;
        }

        static float Mod(float a, float b) => a - b * Mathf.Floor(a / b);

        /// <summary>Returns true and the water surface height if the point is above the sea.</summary>
        public bool TryGetWater(Vector3 p, out float surfaceY)
        {
            surfaceY = WaterLevel;
            // Water starts where the beach slope drops below the water level.
            float waterEdgeX = SlopeStartX + BeachSlopeLength * (-WaterLevel / SeaDepth);
            return p.x > waterEdgeX && p.x < SeaStartX + SeaLength && p.y < WaterLevel + 0.5f;
        }
    }
}
