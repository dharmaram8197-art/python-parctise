using System.Collections.Generic;
using PortSolara.Core;
using UnityEngine;

namespace PortSolara.World
{
    /// <summary>
    /// Rotates the sun, blends light colour/intensity, ambient and fog, and switches
    /// street lamps on at night. One in-game day lasts <see cref="dayLengthMinutes"/> real minutes.
    /// </summary>
    public class DayNightCycle : MonoBehaviour
    {
        [Range(0f, 24f)] public float timeOfDay = 9f;
        public float dayLengthMinutes = 16f;
        public Light sun;
        public Camera targetCamera;

        readonly List<Renderer> _lamps = new List<Renderer>();
        Material _lampOn, _lampOff;
        bool _lampsLit;

        static readonly Color NightAmbient = new Color(0.10f, 0.12f, 0.20f);
        static readonly Color DayAmbient = new Color(0.55f, 0.58f, 0.62f);
        static readonly Color DuskSun = new Color(1f, 0.55f, 0.30f);
        static readonly Color NoonSun = new Color(1f, 0.96f, 0.88f);
        static readonly Color NightSky = new Color(0.02f, 0.03f, 0.08f);
        static readonly Color DaySky = new Color(0.52f, 0.72f, 0.92f);

        public string ClockText
        {
            get
            {
                int h = Mathf.FloorToInt(timeOfDay) % 24;
                int m = Mathf.FloorToInt((timeOfDay - Mathf.Floor(timeOfDay)) * 60f);
                return $"{h:00}:{m:00}";
            }
        }

        public void RegisterLamps(IEnumerable<Renderer> lamps)
        {
            _lamps.AddRange(lamps);
            _lampOn = MaterialLibrary.Get(new Color(1f, 0.92f, 0.6f) * 1.6f);
            _lampOff = MaterialLibrary.Get(new Color(0.6f, 0.6f, 0.55f));
            _lampsLit = false;
            SetLamps(IsNight);
        }

        public bool IsNight => timeOfDay < 6.3f || timeOfDay > 19.2f;

        void Update()
        {
            if (dayLengthMinutes > 0f)
                timeOfDay = Mathf.Repeat(timeOfDay + Time.deltaTime * 24f / (dayLengthMinutes * 60f), 24f);
            ApplyLighting();
        }

        public void ApplyLighting()
        {
            // 6:00 → sunrise (0°), 12:00 → noon (90°), 18:00 → sunset (180°)
            float sunAngle = (timeOfDay - 6f) / 24f * 360f;
            float elevation = Mathf.Sin(sunAngle * Mathf.Deg2Rad); // -1..1
            float day = Mathf.Clamp01(elevation * 3f + 0.15f);      // soft transition around horizon

            if (sun != null)
            {
                sun.transform.rotation = Quaternion.Euler(sunAngle, -40f, 0f);
                sun.intensity = Mathf.Lerp(0.05f, 1.15f, day);
                sun.color = Color.Lerp(DuskSun, NoonSun, Mathf.Clamp01(elevation * 2f));
                sun.shadows = day > 0.05f ? LightShadows.Soft : LightShadows.None;
            }

            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = Color.Lerp(NightAmbient, DayAmbient, day);
            Color sky = Color.Lerp(NightSky, DaySky, day);
            RenderSettings.fogColor = Color.Lerp(sky, Color.white, 0.25f * day);
            if (targetCamera != null && targetCamera.clearFlags == CameraClearFlags.SolidColor)
                targetCamera.backgroundColor = sky;

            bool night = IsNight;
            if (night != _lampsLit) SetLamps(night);
        }

        void SetLamps(bool on)
        {
            _lampsLit = on;
            var mat = on ? _lampOn : _lampOff;
            if (mat == null) return;
            foreach (var r in _lamps)
                if (r != null) r.sharedMaterial = mat;
        }
    }
}
