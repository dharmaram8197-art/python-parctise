using UnityEngine;

namespace PortSolara.World
{
    /// <summary>Global, read-only queries about the loaded world (water, spawn points).</summary>
    public static class WorldQuery
    {
        public static CityLayout Layout { get; set; }

        public static bool TryGetWater(Vector3 position, out float surfaceY)
        {
            surfaceY = CityLayout.WaterLevel;
            return Layout != null && Layout.TryGetWater(position, out surfaceY);
        }
    }
}
