using PortSolara.Input;
using UnityEngine;

namespace PortSolara.CameraSystem
{
    /// <summary>
    /// Orbit camera for on-foot and vehicle play, with collision so it never clips into
    /// buildings, auto-recentring behind moving vehicles, and a slow menu fly-around.
    /// </summary>
    [DefaultExecutionOrder(100)]
    public class ThirdPersonCamera : MonoBehaviour
    {
        public enum Mode { Menu, OnFoot, Vehicle }

        public Mode CurrentMode { get; private set; } = Mode.Menu;
        public float Yaw { get; private set; }
        public float Pitch { get; private set; } = 12f;

        public float onFootDistance = 4.2f;
        public float vehicleDistance = 7.5f;
        public float minPitch = -35f, maxPitch = 70f;
        public float collisionRadius = 0.25f;

        Transform _target;
        Vector3 _menuCenter;
        float _menuRadius = 160f;
        float _lastLookTime;
        float _currentDistance;
        readonly RaycastHit[] _hits = new RaycastHit[16];

        public void SetMenu(Vector3 cityCenter, float radius)
        {
            CurrentMode = Mode.Menu;
            _menuCenter = cityCenter;
            _menuRadius = radius;
            _target = null;
        }

        public void Follow(Transform target, Mode mode, bool snapBehind = true)
        {
            _target = target;
            CurrentMode = mode;
            if (snapBehind && target != null)
            {
                Yaw = target.eulerAngles.y;
                Pitch = mode == Mode.Vehicle ? 10f : 12f;
            }
            _currentDistance = mode == Mode.Vehicle ? vehicleDistance : onFootDistance;
        }

        void LateUpdate()
        {
            if (CurrentMode == Mode.Menu || _target == null)
            {
                float t = Time.unscaledTime * 0.05f;
                var pos = _menuCenter + new Vector3(Mathf.Cos(t) * _menuRadius, _menuRadius * 0.45f, Mathf.Sin(t) * _menuRadius);
                transform.position = pos;
                transform.rotation = Quaternion.LookRotation(_menuCenter + Vector3.up * 15f - pos);
                return;
            }

            float dt = Time.deltaTime;
            if (dt <= 0f) return; // paused
            var input = InputRouter.Current;

            if (input.LookActive)
            {
                Yaw += input.Look.x;
                Pitch = Mathf.Clamp(Pitch - input.Look.y, minPitch, maxPitch);
                _lastLookTime = Time.time;
            }

            bool vehicle = CurrentMode == Mode.Vehicle;
            if (vehicle)
            {
                // Recentre behind the car after a moment without manual look input.
                var rb = _target.GetComponentInParent<Rigidbody>();
                float speed = rb != null ? rb.linearVelocity.magnitude : 0f;
                if (Time.time - _lastLookTime > 1.5f && speed > 3f)
                {
                    Vector3 vel = rb.linearVelocity;
                    float desiredYaw = Vector3.Dot(vel, _target.forward) < -1f
                        ? _target.eulerAngles.y   // reversing: stay behind the car's nose direction
                        : Quaternion.LookRotation(new Vector3(vel.x, 0f, vel.z).normalized + _target.forward * 0.01f).eulerAngles.y;
                    Yaw = Mathf.LerpAngle(Yaw, desiredYaw, dt * 2.5f);
                    Pitch = Mathf.Lerp(Pitch, 10f, dt * 1.5f);
                }
            }

            float distance = vehicle ? vehicleDistance : onFootDistance;
            Vector3 pivot = _target.position + Vector3.up * (vehicle ? 1.8f : 1.6f);
            Quaternion rot = Quaternion.Euler(Pitch, Yaw, 0f);
            Vector3 dir = rot * Vector3.back;

            // Collision: sphere-cast from pivot towards the desired position, ignoring the target itself.
            float allowed = distance;
            int count = Physics.SphereCastNonAlloc(pivot, collisionRadius, dir, _hits, distance, ~0, QueryTriggerInteraction.Ignore);
            Transform root = _target.root;
            for (int i = 0; i < count; i++)
            {
                if (_hits[i].transform.root == root) continue;
                if (_hits[i].distance > 0f && _hits[i].distance < allowed) allowed = _hits[i].distance;
            }
            allowed = Mathf.Max(0.6f, allowed - 0.1f);
            // Move in quickly when blocked, ease out when clear.
            _currentDistance = allowed < _currentDistance ? allowed : Mathf.Lerp(_currentDistance, allowed, dt * 3f);

            transform.position = pivot + dir * _currentDistance;
            transform.rotation = rot;
        }
    }
}
