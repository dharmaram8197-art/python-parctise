using System;
using System.Collections.Generic;
using PortSolara.Input;
using PortSolara.Save;
using PortSolara.Settings;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace PortSolara.UI
{
    /// <summary>Base for full-screen menus. Each screen owns a root GameObject it shows/hides.</summary>
    public abstract class MenuScreen
    {
        public GameObject Root { get; protected set; }
        protected Selectable FirstSelectable;
        public bool IsVisible => Root != null && Root.activeSelf;

        public virtual void Show()
        {
            Root.SetActive(true);
            Refresh();
            if (Gamepad.current != null && FirstSelectable != null && EventSystem.current != null)
                EventSystem.current.SetSelectedGameObject(FirstSelectable.gameObject);
        }

        public virtual void Hide() => Root.SetActive(false);
        public virtual void Refresh() { }
        /// <summary>Handle Escape/B. Return true if the screen consumed it.</summary>
        public virtual bool Back() => false;
        public virtual void Tick() { }
    }

    public class MainMenuScreen : MenuScreen
    {
        readonly GameManager _gm;
        readonly Action _openSettings;
        Button _continue;
        Text _status;

        public MainMenuScreen(Transform parent, GameManager gm, Action openSettings)
        {
            _gm = gm;
            _openSettings = openSettings;
            Root = UIFactory.NewModal("MainMenu", parent, 760f, out var panel).gameObject;
            var col = UIFactory.Column(panel, 22f, 50);
            var title = UIFactory.NewText("Title", col, "PORT SOLARA", 84);
            title.color = UIFactory.AccentColor;
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 120f;
            var sub = UIFactory.NewText("Subtitle", col, "Open-world prototype  ·  v" + Application.version, 28);
            sub.gameObject.AddComponent<LayoutElement>().preferredHeight = 50f;

            var play = UIFactory.NewButton("Play", col, "New Game", () => _gm.NewGame());
            _continue = UIFactory.NewButton("Continue", col, "Continue", OnContinue);
            UIFactory.NewButton("Settings", col, "Settings", () => _openSettings());
            if (Application.platform != RuntimePlatform.WebGLPlayer)
                UIFactory.NewButton("Quit", col, "Quit", () => _gm.QuitGame());

            _status = UIFactory.NewText("Status", col, "", 26);
            _status.gameObject.AddComponent<LayoutElement>().preferredHeight = 60f;
            FirstSelectable = play;
        }

        void OnContinue()
        {
            if (!_gm.ContinueGame(out string error)) _status.text = error;
        }

        public override void Refresh()
        {
            bool has = SaveSystem.HasSave();
            _continue.interactable = has;
            UIFactory.SetLabel(_continue, has ? "Continue" : "Continue (no save yet)");
            _status.text = "";
        }
    }

    public class PauseScreen : MenuScreen
    {
        readonly GameManager _gm;
        Button _load;
        Text _status;

        public PauseScreen(Transform parent, GameManager gm, Action openSettings)
        {
            _gm = gm;
            Root = UIFactory.NewModal("PauseMenu", parent, 700f, out var panel).gameObject;
            var col = UIFactory.Column(panel, 16f, 40);
            var title = UIFactory.NewText("Title", col, "PAUSED", 64);
            title.gameObject.AddComponent<LayoutElement>().preferredHeight = 90f;

            var resume = UIFactory.NewButton("Resume", col, "Resume", () => _gm.Resume());
            UIFactory.NewButton("Save", col, "Save Game", () =>
            {
                _gm.SaveGame(out string msg);
                _status.text = msg;
                Refresh(keepStatus: true);
            });
            _load = UIFactory.NewButton("Load", col, "Load Game", () =>
            {
                if (_gm.LoadGame(out string msg)) _gm.Resume();
                else _status.text = msg;
            });
            UIFactory.NewButton("RestartMission", col, "Restart Mission", () =>
            {
                _gm.RestartMission();
                _gm.Resume();
            });
            UIFactory.NewButton("Settings", col, "Settings", () => openSettings());
            UIFactory.NewButton("MainMenu", col, "Quit to Main Menu", () => _gm.ReturnToMainMenu());
            _status = UIFactory.NewText("Status", col, "", 26);
            _status.gameObject.AddComponent<LayoutElement>().preferredHeight = 50f;
            FirstSelectable = resume;
        }

        public override void Refresh() => Refresh(false);

        void Refresh(bool keepStatus)
        {
            _load.interactable = SaveSystem.HasSave();
            if (!keepStatus) _status.text = "Unsaved progress is lost when quitting to the menu.";
        }

        public override bool Back()
        {
            _gm.Resume();
            return true;
        }
    }

    public class SettingsScreen : MenuScreen
    {
        readonly Action _onClose;
        readonly Action _openBindings;
        readonly List<Action> _refreshers = new List<Action>();

        public SettingsScreen(Transform parent, Action onClose, Action openBindings)
        {
            _onClose = onClose;
            _openBindings = openBindings;
            Root = UIFactory.NewModal("Settings", parent, 1100f, out var panel).gameObject;

            var title = UIFactory.NewText("Title", panel, "SETTINGS", 56);
            UIFactory.Anchor(title.rectTransform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -20), new Vector2(800, 80));

            var listHolder = UIFactory.NewRect("ListHolder", panel);
            UIFactory.Stretch(listHolder);
            listHolder.offsetMax = new Vector2(0, -110);
            var list = UIFactory.ScrollList(listHolder, out _);

            bool mobile = GameSettings.IsMobile;

            Row(list, "Graphics Quality", () => CycleQuality(-1), () => CycleQuality(1), () => GameSettings.QualityName);
            Row(list, mobile ? "Frame Rate Limit" : "Frame Rate Limit (V-Sync off)",
                () => { GameSettings.FrameRateIndex--; Commit(); }, () => { GameSettings.FrameRateIndex++; Commit(); },
                () => GameSettings.TargetFrameRate + " FPS");
            if (mobile)
                Row(list, "Render Resolution", () => { GameSettings.RenderScaleIndex--; Commit(); }, () => { GameSettings.RenderScaleIndex++; Commit(); },
                    () => Mathf.RoundToInt(GameSettings.RenderScale * 100) + "%");
            Row(list, "Draw Distance", () => { GameSettings.DrawDistanceIndex--; Commit(); }, () => { GameSettings.DrawDistanceIndex++; Commit(); },
                () => GameSettings.DrawDistance + " m");
            if (!mobile)
            {
                Row(list, "V-Sync", ToggleVSync, ToggleVSync, () => GameSettings.VSync ? "On" : "Off");
                Row(list, "Display Mode", ToggleFullscreen, ToggleFullscreen, () => GameSettings.Fullscreen ? "Fullscreen" : "Windowed");
            }
            Row(list, "Look Sensitivity", () => { GameSettings.LookSensitivity -= 0.1f; Commit(); }, () => { GameSettings.LookSensitivity += 0.1f; Commit(); },
                () => GameSettings.LookSensitivity.ToString("0.0"));
            Row(list, "Invert Look Y", ToggleInvert, ToggleInvert, () => GameSettings.InvertY ? "On" : "Off");
            Row(list, "Touch Controls", () => CycleTouch(-1), () => CycleTouch(1), () => GameSettings.TouchMode.ToString());
            Row(list, "Touch Button Size", () => { GameSettings.TouchScale -= 0.1f; Commit(); }, () => { GameSettings.TouchScale += 0.1f; Commit(); },
                () => Mathf.RoundToInt(GameSettings.TouchScale * 100) + "%");
            Row(list, "Touch Opacity", () => { GameSettings.TouchOpacity -= 0.1f; Commit(); }, () => { GameSettings.TouchOpacity += 0.1f; Commit(); },
                () => Mathf.RoundToInt(GameSettings.TouchOpacity * 100) + "%");
            Row(list, "Minimap", ToggleMinimap, ToggleMinimap, () => GameSettings.ShowMinimap ? "On" : "Off");

            Button first = null;
            if (!mobile) first = UIFactory.NewButton("KeyBindings", list, "Key Bindings…", () => _openBindings());
            var reset = UIFactory.NewButton("Reset", list, "Reset to Defaults", () =>
            {
                GameSettings.ResetToDefaults();
                Commit();
            });
            UIFactory.NewButton("Back", list, "Back", () => _onClose());
            FirstSelectable = first != null ? first : reset;
        }

        void CycleQuality(int dir)
        {
            int count = Mathf.Max(1, QualitySettings.names.Length);
            GameSettings.QualityLevel = (GameSettings.QualityLevel + dir + count) % count;
            Commit();
        }

        void ToggleVSync() { GameSettings.VSync = !GameSettings.VSync; Commit(); }
        void ToggleFullscreen() { GameSettings.Fullscreen = !GameSettings.Fullscreen; Commit(); }
        void ToggleInvert() { GameSettings.InvertY = !GameSettings.InvertY; Commit(); }
        void ToggleMinimap() { GameSettings.ShowMinimap = !GameSettings.ShowMinimap; Commit(); }

        void CycleTouch(int dir)
        {
            int n = Enum.GetValues(typeof(TouchControlsMode)).Length;
            GameSettings.TouchMode = (TouchControlsMode)(((int)GameSettings.TouchMode + dir + n) % n);
            Commit();
        }

        void Commit()
        {
            GameSettings.Save();   // clamps values
            GameSettings.Apply();
            Refresh();
        }

        void Row(Transform list, string label, Action prev, Action next, Func<string> value)
        {
            var text = UIFactory.StepperRow(list, label, prev, next);
            _refreshers.Add(() => text.text = value());
        }

        public override void Refresh()
        {
            foreach (var r in _refreshers) r();
        }

        public override bool Back()
        {
            _onClose();
            return true;
        }
    }

    public class KeyBindingsScreen : MenuScreen
    {
        readonly Action _onClose;
        readonly Dictionary<GameAction, Button> _buttons = new Dictionary<GameAction, Button>();
        GameAction? _listening;
        int _listenStartFrame;
        Text _hint;

        public KeyBindingsScreen(Transform parent, Action onClose)
        {
            _onClose = onClose;
            Root = UIFactory.NewModal("KeyBindings", parent, 1100f, out var panel).gameObject;
            var title = UIFactory.NewText("Title", panel, "KEY BINDINGS", 52);
            UIFactory.Anchor(title.rectTransform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -20), new Vector2(800, 80));
            var holder = UIFactory.NewRect("ListHolder", panel);
            UIFactory.Stretch(holder);
            holder.offsetMax = new Vector2(0, -110);
            var list = UIFactory.ScrollList(holder, out _);

            _hint = UIFactory.NewText("Hint", list, "Click an action, then press the new key. Esc cancels. Pause is always Esc.", 26);
            _hint.gameObject.AddComponent<LayoutElement>().preferredHeight = 70f;

            Button first = null;
            foreach (GameAction a in Enum.GetValues(typeof(GameAction)))
            {
                var row = UIFactory.NewRect(a + "Row", list);
                row.gameObject.AddComponent<LayoutElement>().preferredHeight = 80f;
                var h = row.gameObject.AddComponent<HorizontalLayoutGroup>();
                h.spacing = 12f; h.childControlWidth = true; h.childControlHeight = true; h.childForceExpandWidth = false;
                var l = UIFactory.NewText("Label", row, KeyBindings.DisplayName(a), 28, TextAnchor.MiddleLeft);
                l.gameObject.AddComponent<LayoutElement>().flexibleWidth = 1f;
                var action = a;
                var b = UIFactory.NewButton("Bind", row, "-", () => StartListening(action), 28);
                b.GetComponent<LayoutElement>().preferredWidth = 300f;
                _buttons[a] = b;
                if (first == null) first = b;
            }
            UIFactory.NewButton("ResetBindings", list, "Reset Bindings", () =>
            {
                KeyBindingsStore.Current.ResetToDefaults();
                KeyBindingsStore.Save();
                Refresh();
            });
            UIFactory.NewButton("Back", list, "Back", () => { _listening = null; _onClose(); });
            FirstSelectable = first;
        }

        void StartListening(GameAction a)
        {
            _listening = a;
            _listenStartFrame = Time.frameCount;
            UIFactory.SetLabel(_buttons[a], "Press a key…");
        }

        public override void Tick()
        {
            if (_listening == null || Keyboard.current == null) return;
            if (Time.frameCount <= _listenStartFrame + 1) return; // ignore the key/click that opened listening
            var kb = Keyboard.current;
            if (kb.escapeKey.wasPressedThisFrame)
            {
                _listening = null;
                Refresh();
                return;
            }
            foreach (var key in kb.allKeys)
            {
                if (key == null || !key.wasPressedThisFrame) continue;
                if (KeyBindingsStore.Current.Set(_listening.Value, key.keyCode))
                {
                    KeyBindingsStore.Save();
                    _listening = null;
                    Refresh();
                }
                return;
            }
        }

        public override void Refresh()
        {
            foreach (var kv in _buttons)
                UIFactory.SetLabel(kv.Value, KeyBindingsStore.Current.Get(kv.Key).ToString());
        }

        public override bool Back()
        {
            if (_listening != null) return true; // Tick() handles Esc as "cancel"
            _onClose();
            return true;
        }
    }
}
