using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace PortSolara.UI
{
    /// <summary>
    /// Builds uGUI elements from code so the project needs no prefab or font assets to run.
    /// Uses Unity's built-in LegacyRuntime font. When a UI artist joins, these screens can be
    /// rebuilt as prefabs with the same public API.
    /// </summary>
    public static class UIFactory
    {
        public static readonly Color PanelColor = new Color(0.05f, 0.07f, 0.10f, 0.88f);
        public static readonly Color ButtonColor = new Color(0.14f, 0.18f, 0.24f, 0.95f);
        public static readonly Color AccentColor = new Color(1f, 0.55f, 0.25f, 1f);
        public static readonly Color TextColor = new Color(0.95f, 0.95f, 0.95f, 1f);

        static Font _font;
        static Sprite _circle;

        public static Font Font
        {
            get
            {
                if (_font == null) _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                return _font;
            }
        }

        /// <summary>Procedurally generated anti-aliased circle sprite for joysticks and round buttons.</summary>
        public static Sprite Circle
        {
            get
            {
                if (_circle != null) return _circle;
                const int size = 128;
                var tex = new Texture2D(size, size, TextureFormat.RGBA32, false) { name = "UICircle", wrapMode = TextureWrapMode.Clamp };
                var px = new Color32[size * size];
                float r = size * 0.5f - 1f;
                for (int y = 0; y < size; y++)
                    for (int x = 0; x < size; x++)
                    {
                        float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(size * 0.5f, size * 0.5f));
                        byte a = (byte)(Mathf.Clamp01(r - d + 0.5f) * 255);
                        px[y * size + x] = new Color32(255, 255, 255, a);
                    }
                tex.SetPixels32(px);
                tex.Apply(false, true);
                _circle = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f);
                return _circle;
            }
        }

        public static RectTransform NewRect(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            return (RectTransform)go.transform;
        }

        public static RectTransform Stretch(RectTransform rt, float inset = 0f)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = new Vector2(inset, inset);
            rt.offsetMax = new Vector2(-inset, -inset);
            return rt;
        }

        public static RectTransform Anchor(RectTransform rt, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size)
        {
            rt.anchorMin = rt.anchorMax = anchor;
            rt.pivot = pivot;
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
            return rt;
        }

        public static Image NewImage(string name, Transform parent, Color color, Sprite sprite = null)
        {
            var rt = NewRect(name, parent);
            var img = rt.gameObject.AddComponent<Image>();
            img.color = color;
            img.sprite = sprite;
            return img;
        }

        public static Text NewText(string name, Transform parent, string content, int size = 32, TextAnchor align = TextAnchor.MiddleCenter)
        {
            var rt = NewRect(name, parent);
            var t = rt.gameObject.AddComponent<Text>();
            t.font = Font;
            t.text = content;
            t.fontSize = size;
            t.alignment = align;
            t.color = TextColor;
            t.raycastTarget = false;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            var shadow = rt.gameObject.AddComponent<Shadow>();
            shadow.effectColor = new Color(0, 0, 0, 0.6f);
            shadow.effectDistance = new Vector2(2, -2);
            return t;
        }

        public static Button NewButton(string name, Transform parent, string label, UnityAction onClick, int fontSize = 34)
        {
            var img = NewImage(name, parent, ButtonColor);
            var btn = img.gameObject.AddComponent<Button>();
            var colors = btn.colors;
            colors.highlightedColor = new Color(1.25f, 1.25f, 1.25f, 1f);
            colors.selectedColor = AccentColor;
            colors.pressedColor = AccentColor;
            colors.disabledColor = new Color(0.6f, 0.6f, 0.6f, 0.5f);
            btn.colors = colors;
            if (onClick != null) btn.onClick.AddListener(onClick);
            var txt = NewText("Label", img.transform, label, fontSize);
            Stretch(txt.rectTransform, 6f);
            var le = img.gameObject.AddComponent<LayoutElement>();
            le.preferredHeight = 84f;
            le.minHeight = 72f;
            return btn;
        }

        public static void SetLabel(Button b, string label)
        {
            var t = b.GetComponentInChildren<Text>();
            if (t != null) t.text = label;
        }

        /// <summary>Full-screen dimmed panel with a centred vertical column.</summary>
        public static RectTransform NewModal(string name, Transform parent, float columnWidth, out RectTransform column)
        {
            var bg = NewImage(name, parent, new Color(0, 0, 0, 0.55f));
            Stretch(bg.rectTransform);
            var panel = NewImage("Panel", bg.transform, PanelColor);
            Anchor(panel.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(columnWidth, 0));
            panel.rectTransform.anchorMin = new Vector2(0.5f, 0.06f);
            panel.rectTransform.anchorMax = new Vector2(0.5f, 0.94f);
            panel.rectTransform.sizeDelta = new Vector2(columnWidth, 0);
            column = panel.rectTransform;
            return bg.rectTransform;
        }

        /// <summary>Scrollable vertical list (for settings on small phone screens).</summary>
        public static RectTransform ScrollList(Transform parent, out ScrollRect scroll)
        {
            var viewport = NewImage("Viewport", parent, new Color(0, 0, 0, 0.01f));
            Stretch(viewport.rectTransform, 20f);
            viewport.gameObject.AddComponent<RectMask2D>();

            var content = NewRect("Content", viewport.transform);
            content.anchorMin = new Vector2(0, 1);
            content.anchorMax = new Vector2(1, 1);
            content.pivot = new Vector2(0.5f, 1f);
            content.offsetMin = content.offsetMax = Vector2.zero;
            var vlg = content.gameObject.AddComponent<VerticalLayoutGroup>();
            vlg.spacing = 14f;
            vlg.childControlHeight = true;
            vlg.childControlWidth = true;
            vlg.childForceExpandHeight = false;
            vlg.childForceExpandWidth = true;
            vlg.padding = new RectOffset(10, 10, 10, 10);
            var fitter = content.gameObject.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            scroll = viewport.gameObject.AddComponent<ScrollRect>();
            scroll.content = content;
            scroll.viewport = viewport.rectTransform;
            scroll.horizontal = false;
            scroll.movementType = ScrollRect.MovementType.Clamped;
            scroll.scrollSensitivity = 40f;
            return content;
        }

        /// <summary>Vertical layout column inside a panel.</summary>
        public static RectTransform Column(Transform parent, float spacing = 18f, int padding = 40)
        {
            var col = NewRect("Column", parent);
            Stretch(col);
            var vlg = col.gameObject.AddComponent<VerticalLayoutGroup>();
            vlg.spacing = spacing;
            vlg.padding = new RectOffset(padding, padding, padding, padding);
            vlg.childAlignment = TextAnchor.MiddleCenter;
            vlg.childControlHeight = true;
            vlg.childControlWidth = true;
            vlg.childForceExpandHeight = false;
            vlg.childForceExpandWidth = true;
            return col;
        }

        /// <summary>A settings row: label on the left, "◀ value ▶" stepper on the right.</summary>
        public static Text StepperRow(Transform parent, string label, Action onPrev, Action onNext)
        {
            var row = NewRect(label + "Row", parent);
            row.gameObject.AddComponent<LayoutElement>().preferredHeight = 80f;
            var h = row.gameObject.AddComponent<HorizontalLayoutGroup>();
            h.spacing = 12f;
            h.childControlWidth = true;
            h.childControlHeight = true;
            h.childForceExpandWidth = false;
            h.childForceExpandHeight = true;

            var l = NewText("Label", row, label, 30, TextAnchor.MiddleLeft);
            l.gameObject.AddComponent<LayoutElement>().flexibleWidth = 1f;

            var prev = NewButton("Prev", row, "<", () => onPrev());
            prev.GetComponent<LayoutElement>().preferredWidth = 90f;
            var valueBg = NewImage("ValueBg", row, new Color(0, 0, 0, 0.35f));
            valueBg.gameObject.AddComponent<LayoutElement>().preferredWidth = 260f;
            var value = NewText("Value", valueBg.transform, "-", 30);
            Stretch(value.rectTransform, 4f);
            var next = NewButton("Next", row, ">", () => onNext());
            next.GetComponent<LayoutElement>().preferredWidth = 90f;
            return value;
        }
    }
}
