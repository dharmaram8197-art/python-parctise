using PortSolara.World;
using UnityEngine;
using UnityEngine.UI;

namespace PortSolara.UI
{
    /// <summary>
    /// Top-down orthographic camera rendered into a small RenderTexture.
    /// Collapsed: follows the player, north-up. Expanded (Map key / tap): shows the whole city.
    /// Can be disabled in Settings to save GPU/battery on low-end phones.
    /// </summary>
    public class Minimap
    {
        const int SmallSize = 300;
        const float FollowOrtho = 70f;

        Camera _cam;
        RenderTexture _rt;
        RawImage _image;
        RectTransform _marker;
        bool _enabled = true;
        bool _expanded;

        public RawImage Build(Transform parent)
        {
            _rt = new RenderTexture(512, 512, 16, RenderTextureFormat.Default) { name = "MinimapRT" };
            _rt.Create();

            var camGo = new GameObject("MinimapCamera");
            _cam = camGo.AddComponent<Camera>();
            _cam.orthographic = true;
            _cam.orthographicSize = FollowOrtho;
            _cam.targetTexture = _rt;
            _cam.clearFlags = CameraClearFlags.SolidColor;
            _cam.backgroundColor = new Color(0.1f, 0.35f, 0.5f);
            _cam.nearClipPlane = 1f;
            _cam.farClipPlane = 400f;
            _cam.depth = -10;
            _cam.transform.rotation = Quaternion.Euler(90f, 0f, 0f); // looking down, +Z is "up" on the map
            _cam.enabled = false;

            var frame = UIFactory.NewImage("MinimapFrame", parent, new Color(0, 0, 0, 0.6f));
            UIFactory.Anchor(frame.rectTransform, new Vector2(1, 1), new Vector2(1, 1), new Vector2(-24, -24), new Vector2(SmallSize + 8, SmallSize + 8));
            frame.raycastTarget = false;

            _image = new GameObject("Minimap", typeof(RectTransform)).AddComponent<RawImage>();
            _image.transform.SetParent(parent, false);
            _image.texture = _rt;
            UIFactory.Anchor(_image.rectTransform, new Vector2(1, 1), new Vector2(1, 1), new Vector2(-28, -28), new Vector2(SmallSize, SmallSize));

            var marker = UIFactory.NewImage("PlayerMarker", _image.transform, UIFactory.AccentColor, UIFactory.Circle);
            marker.raycastTarget = false;
            _marker = marker.rectTransform;
            _marker.anchorMin = _marker.anchorMax = Vector2.zero;
            _marker.sizeDelta = new Vector2(22, 22);
            var heading = UIFactory.NewImage("Heading", _marker, UIFactory.AccentColor);
            heading.raycastTarget = false;
            UIFactory.Anchor(heading.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0f), new Vector2(0, 6), new Vector2(6, 20));

            _frame = frame.rectTransform;
            return _image;
        }

        RectTransform _frame;

        public void SetEnabled(bool on)
        {
            _enabled = on;
            if (_image != null) _image.gameObject.SetActive(on);
            if (_frame != null) _frame.gameObject.SetActive(on);
            if (!on && _cam != null) _cam.enabled = false;
        }

        public void Tick(Transform follow, CityLayout layout, bool expanded)
        {
            if (!_enabled || _cam == null || follow == null || layout == null)
            {
                if (_cam != null) _cam.enabled = false;
                return;
            }
            _cam.enabled = true;

            if (expanded != _expanded)
            {
                _expanded = expanded;
                float size = expanded ? 860f : SmallSize;
                var anchor = expanded ? new Vector2(0.5f, 0.5f) : new Vector2(1, 1);
                var pos = expanded ? Vector2.zero : new Vector2(-28, -28);
                UIFactory.Anchor(_image.rectTransform, anchor, anchor, pos, new Vector2(size, size));
                UIFactory.Anchor(_frame, anchor, anchor, expanded ? Vector2.zero : new Vector2(-24, -24), new Vector2(size + 8, size + 8));
            }

            Vector3 center;
            if (expanded)
            {
                center = layout.Center + new Vector3(CityLayout.BeachFlatWidth * 0.5f + 15f, 0f, 0f);
                _cam.orthographicSize = Mathf.Max(layout.Width, layout.Depth) * 0.62f;
            }
            else
            {
                center = follow.position;
                _cam.orthographicSize = FollowOrtho;
            }
            _cam.transform.position = new Vector3(center.x, 200f, center.z);

            // Place the player marker using the map camera's projection.
            Vector3 vp = _cam.WorldToViewportPoint(follow.position);
            var r = _image.rectTransform.rect;
            _marker.anchoredPosition = new Vector2(Mathf.Clamp01(vp.x) * r.width, Mathf.Clamp01(vp.y) * r.height);
            _marker.localRotation = Quaternion.Euler(0, 0, -follow.eulerAngles.y);
        }

        public void Dispose()
        {
            if (_rt != null) { _rt.Release(); Object.Destroy(_rt); }
            if (_cam != null) Object.Destroy(_cam.gameObject);
        }
    }
}
