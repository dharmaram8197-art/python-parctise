using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PortSolara.UI
{
    /// <summary>Floating virtual joystick: the knob follows the finger inside the base radius.</summary>
    public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public RectTransform knob;
        public float radius = 110f;
        public Action<Vector2> OnValue;
        public Vector2 Value { get; private set; }

        RectTransform _rt;
        int _pointerId = int.MinValue;

        void Awake() => _rt = (RectTransform)transform;

        public void OnPointerDown(PointerEventData e)
        {
            if (_pointerId != int.MinValue) return;
            _pointerId = e.pointerId;
            OnDrag(e);
        }

        public void OnDrag(PointerEventData e)
        {
            if (e.pointerId != _pointerId) return;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(_rt, e.position, e.pressEventCamera, out Vector2 local)) return;
            Vector2 clamped = Vector2.ClampMagnitude(local, radius);
            if (knob != null) knob.anchoredPosition = clamped;
            Value = clamped / radius;
            OnValue?.Invoke(Value);
        }

        public void OnPointerUp(PointerEventData e)
        {
            if (e.pointerId != _pointerId) return;
            Release();
        }

        public void Release()
        {
            _pointerId = int.MinValue;
            Value = Vector2.zero;
            if (knob != null) knob.anchoredPosition = Vector2.zero;
            OnValue?.Invoke(Vector2.zero);
        }

        void OnDisable() => Release();
    }

    /// <summary>On-screen button supporting both "pressed" (tap) and "held" semantics, multi-touch safe.</summary>
    public class TouchButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
    {
        public Action OnPressed;
        public Action<bool> OnHeld;
        public bool IsHeld { get; private set; }
        Image _img;
        Color _baseColor;

        void Awake()
        {
            _img = GetComponent<Image>();
            if (_img != null) _baseColor = _img.color;
        }

        public void OnPointerDown(PointerEventData e)
        {
            IsHeld = true;
            OnPressed?.Invoke();
            OnHeld?.Invoke(true);
            if (_img != null) _img.color = new Color(UIFactory.AccentColor.r, UIFactory.AccentColor.g, UIFactory.AccentColor.b, _baseColor.a);
        }

        public void OnPointerUp(PointerEventData e) => Release();
        public void OnPointerExit(PointerEventData e) { if (IsHeld && e.pointerPress == gameObject) Release(); }

        public void Release()
        {
            if (!IsHeld) return;
            IsHeld = false;
            OnHeld?.Invoke(false);
            if (_img != null) _img.color = _baseColor;
        }

        public void SetBaseAlpha(float a)
        {
            if (_img == null) _img = GetComponent<Image>();
            _baseColor.a = a;
            if (_img != null && !IsHeld) _img.color = _baseColor;
        }

        void OnDisable() => Release();
    }

    /// <summary>Invisible drag area for camera look (right side of the screen).</summary>
    public class TouchLookArea : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public Action<Vector2> OnDelta;
        int _pointerId = int.MinValue;

        public void OnPointerDown(PointerEventData e)
        {
            if (_pointerId == int.MinValue) _pointerId = e.pointerId;
        }

        public void OnDrag(PointerEventData e)
        {
            if (e.pointerId == _pointerId) OnDelta?.Invoke(e.delta);
        }

        public void OnPointerUp(PointerEventData e)
        {
            if (e.pointerId == _pointerId) _pointerId = int.MinValue;
        }

        void OnDisable() => _pointerId = int.MinValue;
    }

    /// <summary>Keeps a RectTransform inside Screen.safeArea (notches, rounded corners, nav bars).</summary>
    public class SafeAreaFitter : MonoBehaviour
    {
        Rect _applied;
        Vector2Int _screen;

        void Update()
        {
            var sa = UnityEngine.Screen.safeArea;
            var size = new Vector2Int(UnityEngine.Screen.width, UnityEngine.Screen.height);
            if (sa == _applied && size == _screen) return;
            _applied = sa;
            _screen = size;
            if (size.x <= 0 || size.y <= 0) return;
            var rt = (RectTransform)transform;
            rt.anchorMin = new Vector2(sa.xMin / size.x, sa.yMin / size.y);
            rt.anchorMax = new Vector2(sa.xMax / size.x, sa.yMax / size.y);
            rt.offsetMin = rt.offsetMax = Vector2.zero;
        }
    }
}
