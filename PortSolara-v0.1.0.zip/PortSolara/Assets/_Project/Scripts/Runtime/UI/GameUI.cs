using System.Collections.Generic;
using PortSolara.Input;
using PortSolara.Settings;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;

namespace PortSolara.UI
{
    /// <summary>
    /// Root of all UI: canvas, menus, HUD, minimap and touch controls.
    /// Reads game state from <see cref="GameManager"/> and forwards touch input to <see cref="InputRouter"/>.
    /// </summary>
    public class GameUI : MonoBehaviour
    {
        GameManager _gm;
        Canvas _canvas;
        RectTransform _safe;

        MainMenuScreen _mainMenu;
        PauseScreen _pause;
        SettingsScreen _settings;
        KeyBindingsScreen _bindings;
        MenuScreen _settingsReturnTo;

        // HUD
        GameObject _hud;
        Text _objective, _clock, _vehicleInfo, _prompt, _toast;
        float _toastUntil;
        Minimap _minimap;

        // Touch
        GameObject _touchRoot, _footGroup, _carGroup, _lookArea;
        VirtualJoystick _joystick;
        TouchButton _enterBtn, _pauseBtn;
        readonly List<TouchButton> _touchButtons = new List<TouchButton>();
        readonly List<Image> _touchImages = new List<Image>();
        bool _gasHeld, _brakeHeld;

        public bool AnyMenuOpen => _mainMenu.IsVisible || _pause.IsVisible || _settings.IsVisible || _bindings.IsVisible;

        public void Init(GameManager gm)
        {
            _gm = gm;
            EnsureEventSystem();

            var canvasGo = new GameObject("UI", typeof(RectTransform));
            canvasGo.transform.SetParent(transform, false);
            _canvas = canvasGo.AddComponent<Canvas>();
            _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            _canvas.sortingOrder = 10;
            var scaler = canvasGo.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.matchWidthOrHeight = 0.5f;
            canvasGo.AddComponent<GraphicRaycaster>();

            _safe = UIFactory.Stretch(UIFactory.NewRect("SafeArea", canvasGo.transform));
            _safe.gameObject.AddComponent<SafeAreaFitter>();

            BuildHud(_safe);
            BuildTouchControls(_safe);

            // Menus are added last so they render above the HUD.
            _settings = new SettingsScreen(canvasGo.transform, CloseSettings, OpenBindings);
            _bindings = new KeyBindingsScreen(canvasGo.transform, CloseBindings);
            _mainMenu = new MainMenuScreen(canvasGo.transform, gm, () => OpenSettings(_mainMenu));
            _pause = new PauseScreen(canvasGo.transform, gm, () => OpenSettings(_pause));
            _settings.Hide(); _bindings.Hide(); _pause.Hide(); _mainMenu.Hide();

            GameSettings.Changed += ApplyTouchAppearance;
            _gm.StateChanged += OnStateChanged;
            _gm.Toast += ShowToast;
            ApplyTouchAppearance();
        }

        void OnDestroy()
        {
            _minimap?.Dispose();
            GameSettings.Changed -= ApplyTouchAppearance;
            if (_gm != null)
            {
                _gm.StateChanged -= OnStateChanged;
                _gm.Toast -= ShowToast;
            }
        }

        static void EnsureEventSystem()
        {
            if (EventSystem.current != null || FindFirstObjectByType<EventSystem>() != null) return;
            var es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
            es.AddComponent<InputSystemUIInputModule>();
        }

        // ------------------------------------------------------------------ state

        void OnStateChanged(GameState state)
        {
            _settings.Hide();
            _bindings.Hide();
            switch (state)
            {
                case GameState.MainMenu:
                    _pause.Hide();
                    _mainMenu.Show();
                    break;
                case GameState.Paused:
                    _mainMenu.Hide();
                    _pause.Show();
                    break;
                case GameState.Playing:
                    _mainMenu.Hide();
                    _pause.Hide();
                    if (EventSystem.current != null) EventSystem.current.SetSelectedGameObject(null);
                    break;
            }
            ReleaseTouch();
        }

        /// <summary>Escape / B / Back in menus. Returns true if handled.</summary>
        public bool HandleBack()
        {
            if (_bindings.IsVisible) return _bindings.Back();
            if (_settings.IsVisible) return _settings.Back();
            if (_pause.IsVisible) return _pause.Back();
            return false;
        }

        void OpenSettings(MenuScreen from)
        {
            _settingsReturnTo = from;
            from.Hide();
            _settings.Show();
        }

        void CloseSettings()
        {
            _settings.Hide();
            (_settingsReturnTo ?? _mainMenu).Show();
        }

        void OpenBindings()
        {
            _settings.Hide();
            _bindings.Show();
        }

        void CloseBindings()
        {
            _bindings.Hide();
            _settings.Show();
        }

        // ------------------------------------------------------------------ HUD

        void BuildHud(RectTransform parent)
        {
            _hud = UIFactory.Stretch(UIFactory.NewRect("HUD", parent)).gameObject;

            var objBg = UIFactory.NewImage("ObjectiveBg", _hud.transform, new Color(0, 0, 0, 0.45f));
            UIFactory.Anchor(objBg.rectTransform, new Vector2(0, 1), new Vector2(0, 1), new Vector2(24, -24), new Vector2(680, 110));
            _objective = UIFactory.NewText("Objective", objBg.transform, "", 30, TextAnchor.MiddleLeft);
            UIFactory.Stretch(_objective.rectTransform, 16f);

            _minimap = new Minimap();
            var mapImg = _minimap.Build(_hud.transform);
            var mapBtn = mapImg.gameObject.AddComponent<TouchButton>();
            mapBtn.OnPressed = () => InputRouter.Instance?.PressTouchMap();

            _clock = UIFactory.NewText("Clock", _hud.transform, "", 34, TextAnchor.UpperRight);
            UIFactory.Anchor(_clock.rectTransform, new Vector2(1, 1), new Vector2(1, 1), new Vector2(-24, -350), new Vector2(400, 50));
            _vehicleInfo = UIFactory.NewText("VehicleInfo", _hud.transform, "", 30, TextAnchor.UpperRight);
            UIFactory.Anchor(_vehicleInfo.rectTransform, new Vector2(1, 1), new Vector2(1, 1), new Vector2(-24, -400), new Vector2(520, 140));

            _prompt = UIFactory.NewText("Prompt", _hud.transform, "", 34);
            UIFactory.Anchor(_prompt.rectTransform, new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(0, 260), new Vector2(1000, 60));

            _toast = UIFactory.NewText("Toast", _hud.transform, "", 40);
            _toast.color = UIFactory.AccentColor;
            UIFactory.Anchor(_toast.rectTransform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -160), new Vector2(1200, 120));
        }

        void ShowToast(string message)
        {
            _toast.text = message;
            _toastUntil = Time.unscaledTime + 3.5f;
        }

        // ------------------------------------------------------------------ Touch controls

        void BuildTouchControls(RectTransform parent)
        {
            _touchRoot = UIFactory.Stretch(UIFactory.NewRect("TouchControls", parent)).gameObject;

            // Camera look area: right 60% of the screen, below the buttons in draw order.
            var look = UIFactory.NewImage("LookArea", _touchRoot.transform, new Color(0, 0, 0, 0));
            look.rectTransform.anchorMin = new Vector2(0.4f, 0f);
            look.rectTransform.anchorMax = new Vector2(1f, 0.75f);
            look.rectTransform.offsetMin = look.rectTransform.offsetMax = Vector2.zero;
            look.gameObject.AddComponent<TouchLookArea>().OnDelta = d => InputRouter.Instance?.AddTouchLook(d);
            _lookArea = look.gameObject;

            // Joystick (bottom-left)
            var baseImg = UIFactory.NewImage("JoystickBase", _touchRoot.transform, new Color(1, 1, 1, 0.25f), UIFactory.Circle);
            UIFactory.Anchor(baseImg.rectTransform, Vector2.zero, new Vector2(0.5f, 0.5f), new Vector2(260, 260), new Vector2(300, 300));
            var knob = UIFactory.NewImage("Knob", baseImg.transform, new Color(1, 1, 1, 0.6f), UIFactory.Circle);
            UIFactory.Anchor(knob.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(130, 130));
            knob.raycastTarget = false;
            _joystick = baseImg.gameObject.AddComponent<VirtualJoystick>();
            _joystick.knob = knob.rectTransform;
            _joystick.OnValue = v => InputRouter.Instance?.SetTouchMove(v);
            _touchImages.Add(baseImg);
            _touchImages.Add(knob);

            // On-foot buttons
            _footGroup = UIFactory.Stretch(UIFactory.NewRect("OnFoot", _touchRoot.transform)).gameObject;
            MakeTouchButton(_footGroup.transform, "JUMP", new Vector2(-170, 170), 190, b => b.OnPressed = () => InputRouter.Instance?.PressTouchJump());
            MakeTouchButton(_footGroup.transform, "RUN", new Vector2(-390, 140), 150, b => b.OnHeld = h => InputRouter.Instance?.SetTouchSprint(h));
            _enterBtn = MakeTouchButton(_footGroup.transform, "ENTER", new Vector2(-170, 400), 150, b => b.OnPressed = () => InputRouter.Instance?.PressTouchInteract());

            // Vehicle buttons
            _carGroup = UIFactory.Stretch(UIFactory.NewRect("InVehicle", _touchRoot.transform)).gameObject;
            MakeTouchButton(_carGroup.transform, "GAS", new Vector2(-160, 190), 200, b => b.OnHeld = h => { _gasHeld = h; PushThrottle(); });
            MakeTouchButton(_carGroup.transform, "BRAKE", new Vector2(-390, 150), 170, b => b.OnHeld = h => { _brakeHeld = h; PushThrottle(); });
            MakeTouchButton(_carGroup.transform, "DRIFT", new Vector2(-170, 420), 140, b => b.OnHeld = h => InputRouter.Instance?.SetTouchHandbrake(h));
            MakeTouchButton(_carGroup.transform, "EXIT", new Vector2(-380, 380), 130, b => b.OnPressed = () => InputRouter.Instance?.PressTouchInteract());
            MakeTouchButton(_carGroup.transform, "RESET", new Vector2(-560, 300), 120, b => b.OnPressed = () => InputRouter.Instance?.PressTouchReset());

            // Pause (top-centre, away from the minimap)
            _pauseBtn = MakeTouchButton(_touchRoot.transform, "II", Vector2.zero, 110, b => b.OnPressed = () => InputRouter.Instance?.PressTouchPause());
            UIFactory.Anchor((RectTransform)_pauseBtn.transform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -24), new Vector2(110, 110));
        }

        void PushThrottle()
        {
            float t = (_gasHeld ? 1f : 0f) - (_brakeHeld ? 1f : 0f);
            InputRouter.Instance?.SetTouchThrottle(t);
        }

        TouchButton MakeTouchButton(Transform parent, string label, Vector2 fromBottomRight, float size, System.Action<TouchButton> wire)
        {
            var img = UIFactory.NewImage(label + "Button", parent, new Color(0.1f, 0.12f, 0.16f, 0.6f), UIFactory.Circle);
            UIFactory.Anchor(img.rectTransform, new Vector2(1, 0), new Vector2(0.5f, 0.5f), fromBottomRight, new Vector2(size, size));
            var txt = UIFactory.NewText("Label", img.transform, label, Mathf.RoundToInt(size * 0.2f));
            UIFactory.Stretch(txt.rectTransform);
            var b = img.gameObject.AddComponent<TouchButton>();
            wire(b);
            _touchButtons.Add(b);
            return b;
        }

        void ApplyTouchAppearance()
        {
            if (_touchRoot == null) return;
            float a = GameSettings.TouchOpacity;
            float s = GameSettings.TouchScale;
            foreach (var b in _touchButtons)
            {
                b.SetBaseAlpha(a);
                b.transform.localScale = Vector3.one * s;
            }
            if (_joystick != null) _joystick.transform.localScale = Vector3.one * s;
            if (_touchImages.Count >= 2)
            {
                _touchImages[0].color = new Color(1, 1, 1, a * 0.45f);
                _touchImages[1].color = new Color(1, 1, 1, a);
            }
            _minimap?.SetEnabled(GameSettings.ShowMinimap);
        }

        void ReleaseTouch()
        {
            foreach (var b in _touchButtons) b.Release();
            _joystick?.Release();
            _gasHeld = _brakeHeld = false;
            InputRouter.Instance?.ClearTouchState();
        }

        // ------------------------------------------------------------------ per-frame

        void Update()
        {
            if (_gm == null) return;
            _bindings.Tick();

            bool playing = _gm.State == GameState.Playing;
            _hud.SetActive(playing || _gm.State == GameState.Paused);

            bool touch = GameSettings.TouchControlsActive && playing;
            if (_touchRoot.activeSelf != touch)
            {
                _touchRoot.SetActive(touch);
                if (!touch) ReleaseTouch();
            }
            if (touch)
            {
                bool driving = _gm.IsDriving;
                if (_footGroup.activeSelf == driving) { _footGroup.SetActive(!driving); ReleaseTouch(); }
                if (_carGroup.activeSelf != driving) _carGroup.SetActive(driving);
                bool canEnter = _gm.CanEnterVehicle;
                if (_enterBtn.gameObject.activeSelf != canEnter) _enterBtn.gameObject.SetActive(canEnter);
                // While the big map is open, the look area must not swallow the tap that closes it.
                if (_lookArea.activeSelf == _gm.MapExpanded) _lookArea.SetActive(!_gm.MapExpanded);
            }

            if (!_hud.activeSelf)
            {
                _minimap.Tick(null, null, false); // stops the map camera rendering in the main menu
                return;
            }

            _objective.text = $"<b>MISSION: {PortSolara.Missions.MissionManager.MissionName}</b>\n{_gm.Missions.Objective}";
            _clock.text = _gm.DayNight != null ? _gm.DayNight.ClockText : "";

            var v = _gm.Vehicle;
            if (_gm.IsDriving && v != null)
            {
                string status = v.IsWrecked ? "  WRECKED — Reset to tow"
                    : v.IsFlooded ? "  FLOODED — Exit and swim"
                    : _gm.Repair != null && _gm.Repair.IsRepairing ? "  Repairing…" : "";
                _vehicleInfo.text = $"{Mathf.RoundToInt(v.SpeedKmh)} km/h\nCar condition {Mathf.RoundToInt(v.Health)}%{status}";
            }
            else _vehicleInfo.text = "";

            _prompt.text = _gm.InteractionPrompt(touch);
            if (_toast.text.Length > 0 && Time.unscaledTime > _toastUntil) _toast.text = "";

            Transform follow = _gm.IsDriving && v != null ? v.transform : _gm.Player != null ? _gm.Player.transform : null;
            _minimap.Tick(follow, _gm.Layout, _gm.MapExpanded);
        }
    }
}
