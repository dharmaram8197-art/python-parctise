using System;
using PortSolara.Core;
using PortSolara.Input;
using PortSolara.World;
using UnityEngine;

namespace PortSolara.Vehicles
{
    /// <summary>
    /// WheelCollider-based car with arcade assists (speed-sensitive steering, anti-roll bars,
    /// downforce), collision damage that reduces engine power, flip reset, flooding and repair.
    /// Tunables live in <see cref="VehicleSpec"/> so new vehicles are data, not new code.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    public class VehicleController : MonoBehaviour
    {
        [Serializable]
        public class VehicleSpec
        {
            public string displayName = "Solara Coupe";
            public float mass = 1300f;
            public float motorTorquePerWheel = 520f;
            public float brakeTorque = 3200f;
            public float handbrakeTorque = 6000f;
            public float maxSpeed = 50f;            // m/s (180 km/h)
            public float maxReverseSpeed = 9f;
            public float maxSteerLow = 34f;         // degrees at low speed
            public float maxSteerHigh = 9f;         // degrees at max speed
            public float steerResponse = 4.5f;
            public float antiRoll = 9000f;
            public float downforce = 2.2f;
            public float damageThreshold = 6f;      // m/s impact before damage
            public float damagePerMs = 4.5f;
        }

        public VehicleSpec spec = new VehicleSpec();

        public float Health { get; private set; } = 100f;
        public bool HasDriver { get; set; }
        public bool IsWrecked => Health <= 0f;
        public bool IsFlooded { get; private set; }
        public float SpeedMs => _rb != null ? _rb.linearVelocity.magnitude : 0f;
        public float SpeedKmh => SpeedMs * 3.6f;
        public float ForwardSpeed => _rb != null ? Vector3.Dot(_rb.linearVelocity, transform.forward) : 0f;
        public Rigidbody Body => _rb;

        public event Action<float> Damaged;

        Rigidbody _rb;
        WheelCollider[] _wheels;      // FL, FR, RL, RR
        Transform[] _wheelVisuals;
        float _steer;
        Material _bodyMat;
        Color _bodyColor;
        float _defaultRearStiffness;

        public static VehicleController Create(Vector3 position, Quaternion rotation, Color paint)
        {
            var go = new GameObject("Vehicle_SolaraCoupe");
            go.transform.SetPositionAndRotation(position, rotation);
            var rb = go.AddComponent<Rigidbody>();
            var vc = go.AddComponent<VehicleController>();
            vc.Build(rb, paint);
            return vc;
        }

        void Build(Rigidbody rb, Color paint)
        {
            _rb = rb;
            _rb.mass = spec.mass;
            _rb.linearDamping = 0.02f;
            _rb.angularDamping = 0.5f;
            _rb.interpolation = RigidbodyInterpolation.Interpolate;
            _rb.collisionDetectionMode = CollisionDetectionMode.ContinuousSpeculative;

            _bodyColor = paint;
            _bodyMat = MaterialLibrary.CreateUnique(paint);

            // Body collider + visuals
            var col = gameObject.AddComponent<BoxCollider>();
            col.center = new Vector3(0f, 0.8f, 0f);
            col.size = new Vector3(1.9f, 0.75f, 4.4f);
            var cabinCol = gameObject.AddComponent<BoxCollider>();
            cabinCol.center = new Vector3(0f, 1.38f, -0.25f);
            cabinCol.size = new Vector3(1.6f, 0.5f, 2.2f);

            var visual = new GameObject("Visual").transform;
            visual.SetParent(transform, false);
            var body = Primitives.Make(PrimitiveType.Cube, "Body", visual, col.center, col.size, Quaternion.identity, paint, false);
            body.GetComponent<Renderer>().sharedMaterial = _bodyMat;
            var cabin = Primitives.Make(PrimitiveType.Cube, "Cabin", visual, cabinCol.center, cabinCol.size, Quaternion.identity, paint, false);
            cabin.GetComponent<Renderer>().sharedMaterial = _bodyMat;
            var glass = new Color(0.12f, 0.16f, 0.2f);
            Primitives.Make(PrimitiveType.Cube, "Windshield", visual, new Vector3(0f, 1.38f, 0.87f), new Vector3(1.5f, 0.42f, 0.04f), Quaternion.Euler(-25f, 0, 0), glass, false);
            Primitives.Make(PrimitiveType.Cube, "RearGlass", visual, new Vector3(0f, 1.38f, -1.37f), new Vector3(1.5f, 0.42f, 0.04f), Quaternion.Euler(25f, 0, 0), glass, false);
            Primitives.Make(PrimitiveType.Cube, "HeadlightL", visual, new Vector3(-0.65f, 0.85f, 2.2f), new Vector3(0.35f, 0.15f, 0.04f), Quaternion.identity, new Color(1f, 1f, 0.85f), false);
            Primitives.Make(PrimitiveType.Cube, "HeadlightR", visual, new Vector3(0.65f, 0.85f, 2.2f), new Vector3(0.35f, 0.15f, 0.04f), Quaternion.identity, new Color(1f, 1f, 0.85f), false);
            Primitives.Make(PrimitiveType.Cube, "TaillightL", visual, new Vector3(-0.65f, 0.85f, -2.2f), new Vector3(0.35f, 0.15f, 0.04f), Quaternion.identity, new Color(0.8f, 0.05f, 0.05f), false);
            Primitives.Make(PrimitiveType.Cube, "TaillightR", visual, new Vector3(0.65f, 0.85f, -2.2f), new Vector3(0.35f, 0.15f, 0.04f), Quaternion.identity, new Color(0.8f, 0.05f, 0.05f), false);

            // Wheels
            _wheels = new WheelCollider[4];
            _wheelVisuals = new Transform[4];
            Vector3[] positions =
            {
                new Vector3(-0.82f, 0.45f, 1.38f), new Vector3(0.82f, 0.45f, 1.38f),
                new Vector3(-0.82f, 0.45f, -1.38f), new Vector3(0.82f, 0.45f, -1.38f)
            };
            string[] names = { "FL", "FR", "RL", "RR" };
            for (int i = 0; i < 4; i++)
            {
                var wgo = new GameObject("Wheel_" + names[i]);
                wgo.transform.SetParent(transform, false);
                wgo.transform.localPosition = positions[i];
                var wc = wgo.AddComponent<WheelCollider>();
                wc.mass = 20f;
                wc.radius = 0.38f;
                wc.wheelDampingRate = 0.5f;
                wc.suspensionDistance = 0.22f;
                wc.forceAppPointDistance = 0.1f;
                wc.suspensionSpring = new JointSpring { spring = 38000f, damper = 4200f, targetPosition = 0.5f };

                var fwd = wc.forwardFriction;
                fwd.extremumSlip = 0.4f; fwd.extremumValue = 1.1f; fwd.asymptoteSlip = 0.8f; fwd.asymptoteValue = 0.6f; fwd.stiffness = 1.4f;
                wc.forwardFriction = fwd;
                var side = wc.sidewaysFriction;
                side.extremumSlip = 0.25f; side.extremumValue = 1.0f; side.asymptoteSlip = 0.5f; side.asymptoteValue = 0.75f; side.stiffness = 1.6f;
                wc.sidewaysFriction = side;
                _wheels[i] = wc;

                var wv = Primitives.Make(PrimitiveType.Cylinder, "WheelMesh_" + names[i], transform, positions[i],
                    new Vector3(0.76f, 0.12f, 0.76f), Quaternion.Euler(0, 0, 90f), new Color(0.08f, 0.08f, 0.08f), false);
                _wheelVisuals[i] = wv.transform;
            }
            _defaultRearStiffness = _wheels[2].sidewaysFriction.stiffness;
            _wheels[0].ConfigureVehicleSubsteps(5f, 12, 15);
            // Set after all colliders exist so Unity doesn't recompute it; low CoM = stable handling.
            _rb.centerOfMass = new Vector3(0f, 0.35f, 0.05f);
        }

        void Awake()
        {
            if (_rb == null) _rb = GetComponent<Rigidbody>();
        }

        void FixedUpdate()
        {
            if (_wheels == null) return;
            var input = HasDriver ? InputRouter.Current : default;
            float dt = Time.fixedDeltaTime;
            float fwdSpeed = ForwardSpeed;
            float speed = SpeedMs;

            IsFlooded = WorldQuery.TryGetWater(transform.position, out float surface) && transform.position.y + 0.6f < surface;
            bool engineOn = HasDriver && !IsWrecked && !IsFlooded;
            float powerFactor = Mathf.Lerp(0.35f, 1f, Health / 100f);

            // Steering — reduced at speed for stability.
            float steerLimit = Mathf.Lerp(spec.maxSteerLow, spec.maxSteerHigh, Mathf.Clamp01(speed / spec.maxSpeed));
            _steer = Mathf.MoveTowards(_steer, input.Move.x * steerLimit, steerLimit * spec.steerResponse * dt);
            _wheels[0].steerAngle = _steer;
            _wheels[1].steerAngle = _steer;

            float throttle = input.Throttle;
            float motor = 0f, brake = 0f;
            if (engineOn)
            {
                if (throttle > 0.01f)
                {
                    if (fwdSpeed < -1f) brake = spec.brakeTorque * throttle;              // moving backwards → brake first
                    else if (fwdSpeed < spec.maxSpeed) motor = spec.motorTorquePerWheel * throttle * powerFactor;
                }
                else if (throttle < -0.01f)
                {
                    if (fwdSpeed > 1f) brake = spec.brakeTorque * -throttle;               // moving forwards → brake
                    else if (-fwdSpeed < spec.maxReverseSpeed) motor = spec.motorTorquePerWheel * throttle * 0.6f * powerFactor;
                }
                else if (speed < 0.6f) brake = 400f;                                      // hold still on slopes
            }
            else
            {
                brake = HasDriver ? 300f : spec.handbrakeTorque * 0.5f;                  // parked when nobody is driving
            }

            for (int i = 0; i < 4; i++)
            {
                _wheels[i].motorTorque = motor;
                _wheels[i].brakeTorque = brake;
            }

            // Handbrake on rear wheels, with reduced grip for controllable slides.
            bool hb = input.Handbrake && HasDriver;
            for (int i = 2; i < 4; i++)
            {
                if (hb)
                {
                    _wheels[i].brakeTorque = spec.handbrakeTorque;
                    _wheels[i].motorTorque = 0f;
                }
                var f = _wheels[i].sidewaysFriction;
                f.stiffness = Mathf.MoveTowards(f.stiffness, hb ? _defaultRearStiffness * 0.55f : _defaultRearStiffness, dt * 3f);
                _wheels[i].sidewaysFriction = f;
            }

            ApplyAntiRoll(_wheels[0], _wheels[1]);
            ApplyAntiRoll(_wheels[2], _wheels[3]);
            _rb.AddForce(-transform.up * (spec.downforce * speed * speed), ForceMode.Force);

            if (IsFlooded)
            {
                _rb.linearDamping = 1.5f;
                _rb.angularDamping = 2f;
            }
            else
            {
                _rb.linearDamping = 0.02f;
                _rb.angularDamping = 0.5f;
            }
        }

        void ApplyAntiRoll(WheelCollider left, WheelCollider right)
        {
            float travelL = 1f, travelR = 1f;
            bool groundedL = left.GetGroundHit(out WheelHit hitL);
            if (groundedL) travelL = (-left.transform.InverseTransformPoint(hitL.point).y - left.radius) / left.suspensionDistance;
            bool groundedR = right.GetGroundHit(out WheelHit hitR);
            if (groundedR) travelR = (-right.transform.InverseTransformPoint(hitR.point).y - right.radius) / right.suspensionDistance;
            float force = (travelL - travelR) * spec.antiRoll;
            if (groundedL) _rb.AddForceAtPosition(left.transform.up * -force, left.transform.position);
            if (groundedR) _rb.AddForceAtPosition(right.transform.up * force, right.transform.position);
        }

        void LateUpdate()
        {
            if (_wheels == null) return;
            for (int i = 0; i < 4; i++)
            {
                _wheels[i].GetWorldPose(out Vector3 pos, out Quaternion rot);
                _wheelVisuals[i].SetPositionAndRotation(pos, rot * Quaternion.Euler(0f, 0f, 90f));
            }
        }

        void OnCollisionEnter(Collision collision)
        {
            float impact = collision.relativeVelocity.magnitude;
            if (impact <= spec.damageThreshold) return;
            ApplyDamage((impact - spec.damageThreshold) * spec.damagePerMs);
        }

        public void ApplyDamage(float amount)
        {
            if (amount <= 0f || IsWrecked) return;
            Health = Mathf.Max(0f, Health - amount);
            UpdateDamageVisual();
            Damaged?.Invoke(amount);
        }

        /// <summary>Repairs by <paramref name="amount"/> health points (clamped to 100).</summary>
        public void Repair(float amount)
        {
            Health = Mathf.Min(100f, Health + Mathf.Max(0f, amount));
            UpdateDamageVisual();
        }

        public void SetHealth(float value)
        {
            Health = Mathf.Clamp(value, 0f, 100f);
            UpdateDamageVisual();
        }

        void UpdateDamageVisual()
        {
            // Paint darkens and greys out as the car gets damaged.
            float t = 1f - Health / 100f;
            var damaged = Color.Lerp(_bodyColor, new Color(0.15f, 0.13f, 0.12f), t * 0.75f);
            MaterialLibrary.SetColor(_bodyMat, damaged);
        }

        /// <summary>Puts the car back on its wheels (flip/stuck recovery).</summary>
        public void ResetUpright()
        {
            Vector3 fwd = Vector3.ProjectOnPlane(transform.forward, Vector3.up);
            if (fwd.sqrMagnitude < 0.01f) fwd = Vector3.forward;
            Place(transform.position + Vector3.up * 1.5f, Quaternion.LookRotation(fwd.normalized, Vector3.up));
        }

        public void Place(Vector3 position, Quaternion rotation)
        {
            _rb.linearVelocity = Vector3.zero;
            _rb.angularVelocity = Vector3.zero;
            _rb.position = position;
            _rb.rotation = rotation;
            transform.SetPositionAndRotation(position, rotation);
            _steer = 0f;
        }

        /// <summary>World position where a driver can safely get out (left side first, then right, then roof).</summary>
        public Vector3 FindExitPoint(float playerRadius, float playerHeight)
        {
            Vector3[] candidates =
            {
                transform.position + transform.right * -1.8f,
                transform.position + transform.right * 1.8f,
                transform.position + transform.forward * 3.2f,
                transform.position + transform.forward * -3.2f,
            };
            foreach (var c in candidates)
            {
                Vector3 basePos = new Vector3(c.x, transform.position.y + 0.1f, c.z);
                Vector3 bottom = basePos + Vector3.up * (playerRadius + 0.05f);
                Vector3 top = basePos + Vector3.up * (playerHeight - playerRadius);
                if (!Physics.CheckCapsule(bottom, top, playerRadius, ~0, QueryTriggerInteraction.Ignore))
                    return basePos;
            }
            return transform.position + Vector3.up * 2.2f;
        }
    }
}
