using PortSolara.Core;
using UnityEngine;

namespace PortSolara.Vehicles
{
    /// <summary>Repairs a stopped vehicle inside the zone over time. Placed at the garage.</summary>
    public class RepairZone : MonoBehaviour
    {
        public float radius = 6f;
        public float repairPerSecond = 25f;
        public VehicleController vehicle;

        public bool IsRepairing { get; private set; }

        public static RepairZone Create(Vector3 position, VehicleController vehicle, Transform parent)
        {
            var go = new GameObject("RepairZone");
            go.transform.SetParent(parent, false);
            go.transform.position = position;
            var z = go.AddComponent<RepairZone>();
            z.vehicle = vehicle;
            Primitives.Make(PrimitiveType.Cylinder, "Pad", go.transform, new Vector3(0, 0.03f, 0),
                new Vector3(z.radius * 2f, 0.02f, z.radius * 2f), Quaternion.identity, new Color(0.2f, 0.6f, 1f), false);
            return z;
        }

        void Update()
        {
            IsRepairing = false;
            if (vehicle == null || vehicle.Health >= 100f) return;
            Vector3 d = vehicle.transform.position - transform.position;
            d.y = 0f;
            if (d.magnitude > radius || vehicle.SpeedMs > 2f) return;
            IsRepairing = true;
            vehicle.Repair(repairPerSecond * Time.deltaTime);
        }
    }
}
