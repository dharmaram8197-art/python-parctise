using PortSolara.Core;
using PortSolara.Input;
using PortSolara.World;
using UnityEngine;

namespace PortSolara.Player
{
    /// <summary>
    /// Third-person on-foot controller: walk, sprint, jump, swim. Movement is relative
    /// to the camera yaw. Uses CharacterController for robust collision on all platforms.
    /// The visual is a placeholder mannequin with a procedural walk cycle; swap in a
    /// rigged character + Animator later without touching the movement code.
    /// </summary>
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour
    {
        public float walkSpeed = 2.4f;
        public float sprintSpeed = 6.5f;
        public float swimSpeed = 2.2f;
        public float jumpHeight = 1.15f;
        public float gravity = -20f;
        public float turnSpeed = 720f;

        public enum MoveState { Grounded, Airborne, Swimming }
        public MoveState State { get; private set; }
        public float Speed { get; private set; }
        public bool InputEnabled { get; set; } = true;

        /// <summary>Yaw (degrees) that "forward" input is relative to — set by the camera.</summary>
        public float ReferenceYaw { get; set; }

        CharacterController _cc;
        Vector3 _velocity;
        Transform _visual, _legL, _legR, _armL, _armR;
        float _walkPhase;
        Vector3 _safePosition;

        public static PlayerController Create(Vector3 position, Color shirt)
        {
            var go = new GameObject("Player");
            go.transform.position = position;
            var cc = go.AddComponent<CharacterController>();
            cc.height = 1.8f;
            cc.radius = 0.35f;
            cc.center = new Vector3(0f, 0.9f, 0f);
            cc.stepOffset = 0.35f;
            cc.slopeLimit = 50f;
            cc.skinWidth = 0.04f;
            var pc = go.AddComponent<PlayerController>();
            pc.BuildVisual(shirt);
            return pc;
        }

        void BuildVisual(Color shirt)
        {
            var skin = new Color(0.80f, 0.62f, 0.48f);
            var pants = new Color(0.18f, 0.22f, 0.32f);
            _visual = new GameObject("Visual").transform;
            _visual.SetParent(transform, false);
            Primitives.Make(PrimitiveType.Cube, "Torso", _visual, new Vector3(0, 1.22f, 0), new Vector3(0.5f, 0.62f, 0.28f), Quaternion.identity, shirt, false);
            Primitives.Make(PrimitiveType.Sphere, "Head", _visual, new Vector3(0, 1.68f, 0), new Vector3(0.26f, 0.3f, 0.28f), Quaternion.identity, skin, false);
            _legL = Limb("LegL", new Vector3(-0.13f, 0.9f, 0), new Vector3(0.18f, 0.88f, 0.2f), pants);
            _legR = Limb("LegR", new Vector3(0.13f, 0.9f, 0), new Vector3(0.18f, 0.88f, 0.2f), pants);
            _armL = Limb("ArmL", new Vector3(-0.33f, 1.5f, 0), new Vector3(0.13f, 0.6f, 0.14f), shirt);
            _armR = Limb("ArmR", new Vector3(0.33f, 1.5f, 0), new Vector3(0.13f, 0.6f, 0.14f), shirt);
        }

        /// <summary>Creates a limb pivoting from its top.</summary>
        Transform Limb(string name, Vector3 pivot, Vector3 size, Color color)
        {
            var p = new GameObject(name).transform;
            p.SetParent(_visual, false);
            p.localPosition = pivot;
            Primitives.Make(PrimitiveType.Cube, name + "Mesh", p, new Vector3(0, -size.y * 0.5f, 0), size, Quaternion.identity, color, false);
            return p;
        }

        void Awake()
        {
            _cc = GetComponent<CharacterController>();
            _safePosition = transform.position;
        }

        void OnEnable()
        {
            _velocity = Vector3.zero;
        }

        /// <summary>Moves the player instantly (spawn, load, exiting vehicles).</summary>
        public void Teleport(Vector3 position, float yaw)
        {
            if (_cc == null) _cc = GetComponent<CharacterController>();
            _cc.enabled = false;
            transform.SetPositionAndRotation(position, Quaternion.Euler(0f, yaw, 0f));
            _cc.enabled = true;
            _velocity = Vector3.zero;
            _safePosition = position;
        }

        void Update()
        {
            float dt = Time.deltaTime;
            if (dt <= 0f) return;
            var input = InputEnabled ? InputRouter.Current : default;

            // Camera-relative desired direction
            Quaternion refRot = Quaternion.Euler(0f, ReferenceYaw, 0f);
            Vector3 wish = refRot * new Vector3(input.Move.x, 0f, input.Move.y);
            float wishMag = Mathf.Clamp01(wish.magnitude);
            if (wishMag > 0.001f) wish /= wish.magnitude;

            bool inWater = WorldQuery.TryGetWater(transform.position, out float surface) && transform.position.y < surface - 1.0f;
            if (inWater) State = MoveState.Swimming;
            else State = _cc.isGrounded ? MoveState.Grounded : MoveState.Airborne;

            float targetSpeed;
            switch (State)
            {
                case MoveState.Swimming:
                    targetSpeed = swimSpeed * wishMag;
                    // Float with head above water.
                    float targetY = surface - 1.35f;
                    _velocity.y = Mathf.Lerp(_velocity.y, (targetY - transform.position.y) * 3f, dt * 4f);
                    break;
                case MoveState.Grounded:
                    targetSpeed = (input.Sprint ? sprintSpeed : walkSpeed) * wishMag;
                    if (_velocity.y < 0f) _velocity.y = -2f; // keep snapped to ground
                    if (input.JumpPressed) _velocity.y = Mathf.Sqrt(2f * -gravity * jumpHeight);
                    break;
                default:
                    targetSpeed = (input.Sprint ? sprintSpeed : walkSpeed) * wishMag;
                    _velocity.y += gravity * dt;
                    break;
            }

            Vector3 horizontal = wish * targetSpeed;
            Vector3 current = new Vector3(_velocity.x, 0f, _velocity.z);
            float accel = State == MoveState.Airborne ? 4f : 14f;
            current = Vector3.MoveTowards(current, horizontal, accel * AccelScale(targetSpeed) * dt);
            _velocity.x = current.x;
            _velocity.z = current.z;

            _cc.Move(_velocity * dt);
            Speed = current.magnitude;

            if (wishMag > 0.05f)
            {
                var face = Quaternion.LookRotation(wish, Vector3.up);
                transform.rotation = Quaternion.RotateTowards(transform.rotation, face, turnSpeed * dt);
            }

            AnimateVisual(dt);

            // Safety net: fell out of the world → return to last safe ground.
            if (_cc.isGrounded && State == MoveState.Grounded) _safePosition = transform.position;
            if (transform.position.y < -30f) Teleport(_safePosition + Vector3.up, transform.eulerAngles.y);
        }

        static float AccelScale(float s) => Mathf.Max(s, 3f);

        void AnimateVisual(float dt)
        {
            if (_legL == null) return;
            float swing = 0f;
            if (State == MoveState.Swimming)
            {
                _walkPhase += dt * 4f;
                float s = Mathf.Sin(_walkPhase) * 50f;
                _armL.localRotation = Quaternion.Euler(-150f + s, 0, 0);
                _armR.localRotation = Quaternion.Euler(-150f - s, 0, 0);
                _legL.localRotation = Quaternion.Euler(20f + s * 0.4f, 0, 0);
                _legR.localRotation = Quaternion.Euler(20f - s * 0.4f, 0, 0);
                return;
            }
            if (State == MoveState.Grounded && Speed > 0.1f)
            {
                _walkPhase += dt * Mathf.Lerp(6f, 11f, Speed / sprintSpeed);
                swing = Mathf.Sin(_walkPhase) * Mathf.Lerp(20f, 45f, Speed / sprintSpeed);
            }
            else if (State == MoveState.Airborne)
            {
                swing = 25f;
            }
            _legL.localRotation = Quaternion.Euler(swing, 0, 0);
            _legR.localRotation = Quaternion.Euler(-swing, 0, 0);
            _armL.localRotation = Quaternion.Euler(-swing * 0.8f, 0, 0);
            _armR.localRotation = Quaternion.Euler(swing * 0.8f, 0, 0);
        }
    }
}
