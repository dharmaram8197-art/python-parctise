using NUnit.Framework;
using PortSolara.World;
using UnityEngine;

namespace PortSolara.Tests
{
    public class CityLayoutTests
    {
        [Test]
        public void SameSeed_ProducesIdenticalCity()
        {
            var a = new CityLayout(42);
            var b = new CityLayout(42);
            Assert.AreEqual(a.Buildings.Count, b.Buildings.Count);
            for (int i = 0; i < a.Buildings.Count; i++)
            {
                Assert.AreEqual(a.Buildings[i].Center, b.Buildings[i].Center);
                Assert.AreEqual(a.Buildings[i].Size, b.Buildings[i].Size);
            }
        }

        [Test]
        public void DifferentSeeds_ProduceDifferentCities()
        {
            var a = new CityLayout(1);
            var b = new CityLayout(2);
            bool anyDifferent = a.Buildings.Count != b.Buildings.Count;
            for (int i = 0; !anyDifferent && i < a.Buildings.Count; i++)
                anyDifferent = a.Buildings[i].Size != b.Buildings[i].Size;
            Assert.IsTrue(anyDifferent);
        }

        [Test]
        public void NoBuildingIntrudesOnRoads()
        {
            var city = new CityLayout(7);
            foreach (var b in city.Buildings)
            {
                Vector3 half = b.Size * 0.5f;
                foreach (var corner in new[]
                         {
                             new Vector3(b.Center.x - half.x, 0, b.Center.z - half.z),
                             new Vector3(b.Center.x + half.x, 0, b.Center.z - half.z),
                             new Vector3(b.Center.x - half.x, 0, b.Center.z + half.z),
                             new Vector3(b.Center.x + half.x, 0, b.Center.z + half.z),
                         })
                {
                    Assert.IsFalse(city.IsOnRoad(corner), $"Building corner {corner} is on a road");
                }
            }
        }

        [Test]
        public void SpawnsAndCheckpoints_AreOnRoads()
        {
            var city = new CityLayout();
            Assert.IsTrue(city.IsOnRoad(city.PlayerSpawn), "Player spawn");
            Assert.IsTrue(city.IsOnRoad(city.VehicleSpawn), "Vehicle spawn");
            Assert.IsTrue(city.IsOnRoad(city.GaragePosition), "Garage");
            foreach (var c in city.MissionCheckpoints) Assert.IsTrue(city.IsOnRoad(c), $"Checkpoint {c}");
        }

        [Test]
        public void Water_IsOnlyBeyondTheBeach()
        {
            var city = new CityLayout();
            Assert.IsFalse(city.TryGetWater(city.Center, out _), "City centre is not water");
            Assert.IsTrue(city.TryGetWater(new Vector3(city.SeaStartX + 20f, -3f, city.Center.z), out float y), "Open sea is water");
            Assert.AreEqual(CityLayout.WaterLevel, y);
        }

        [Test]
        public void TooSmallCity_Throws()
        {
            Assert.Throws<System.ArgumentException>(() => new CityLayout(1, 1, 1));
        }
    }
}
