using System.IO;
using NUnit.Framework;
using PortSolara.Input;
using PortSolara.Save;
using UnityEngine;
using UnityEngine.InputSystem;

namespace PortSolara.Tests
{
    public class SaveSystemTests
    {
        string _dir;

        [SetUp]
        public void SetUp()
        {
            _dir = Path.Combine(Path.GetTempPath(), "PortSolaraTests_" + System.Guid.NewGuid().ToString("N"));
            SaveSystem.Directory = _dir;
        }

        [TearDown]
        public void TearDown()
        {
            SaveSystem.Directory = null;
            if (Directory.Exists(_dir)) Directory.Delete(_dir, true);
        }

        [Test]
        public void SaveThenLoad_RoundTrips()
        {
            var data = new SaveData
            {
                playerPosition = new Vector3(1, 2, 3),
                playerYaw = 45f,
                inVehicle = true,
                vehiclePosition = new Vector3(4, 5, 6),
                vehicleRotation = Quaternion.Euler(0, 90, 0),
                vehicleHealth = 63f,
                timeOfDay = 21.5f,
                missionStage = 2
            };
            Assert.IsTrue(SaveSystem.TrySave(data, out var err), err);
            Assert.IsTrue(SaveSystem.HasSave());
            Assert.IsTrue(SaveSystem.TryLoad(out var loaded, out err), err);
            Assert.AreEqual(data.playerPosition, loaded.playerPosition);
            Assert.AreEqual(data.vehicleHealth, loaded.vehicleHealth);
            Assert.AreEqual(data.inVehicle, loaded.inVehicle);
            Assert.AreEqual(data.missionStage, loaded.missionStage);
            Assert.AreEqual(21.5f, loaded.timeOfDay);
        }

        [Test]
        public void CorruptedMainFile_FallsBackToBackup()
        {
            Assert.IsTrue(SaveSystem.TrySave(new SaveData { vehicleHealth = 10f }, out _));
            Assert.IsTrue(SaveSystem.TrySave(new SaveData { vehicleHealth = 20f }, out _)); // first save becomes .bak
            File.WriteAllText(SaveSystem.SlotPath(), "{ this is not json");
            Assert.IsTrue(SaveSystem.TryLoad(out var loaded, out var err), err);
            Assert.AreEqual(10f, loaded.vehicleHealth);
        }

        [Test]
        public void NoSave_ReturnsFalseWithMessage()
        {
            Assert.IsFalse(SaveSystem.HasSave());
            Assert.IsFalse(SaveSystem.TryLoad(out var data, out var err));
            Assert.IsNull(data);
            Assert.IsNotEmpty(err);
        }

        [Test]
        public void FutureVersion_IsRejected()
        {
            var json = SaveSystem.Serialize(new SaveData()).Replace("\"version\": 1", "\"version\": 999");
            Assert.IsFalse(SaveSystem.TryDeserialize(json, out _, out var err));
            StringAssert.Contains("version", err);
        }
    }

    public class KeyBindingsTests
    {
        [Test]
        public void Defaults_AreWASD()
        {
            var kb = new KeyBindings();
            Assert.AreEqual(Key.W, kb.Get(GameAction.MoveForward));
            Assert.AreEqual(Key.A, kb.Get(GameAction.MoveLeft));
            Assert.AreEqual(Key.F, kb.Get(GameAction.Interact));
        }

        [Test]
        public void SerializeParse_RoundTrips()
        {
            var kb = new KeyBindings();
            kb.Set(GameAction.Interact, Key.E);
            kb.Set(GameAction.Jump, Key.J);
            var parsed = KeyBindings.Parse(kb.Serialize());
            Assert.AreEqual(Key.E, parsed.Get(GameAction.Interact));
            Assert.AreEqual(Key.J, parsed.Get(GameAction.Jump));
            Assert.AreEqual(Key.W, parsed.Get(GameAction.MoveForward));
        }

        [Test]
        public void EscapeCannotBeBound()
        {
            var kb = new KeyBindings();
            Assert.IsFalse(kb.Set(GameAction.Jump, Key.Escape));
            Assert.AreEqual(Key.Space, kb.Get(GameAction.Jump));
        }

        [Test]
        public void GarbageInput_KeepsDefaults()
        {
            var kb = KeyBindings.Parse("nonsense;;Jump=NotAKey;Unknown=W;=");
            Assert.AreEqual(Key.Space, kb.Get(GameAction.Jump));
        }
    }
}
