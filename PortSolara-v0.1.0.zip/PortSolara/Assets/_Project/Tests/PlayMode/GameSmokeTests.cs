using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace PortSolara.Tests
{
    /// <summary>Boots the full game in a test scene and exercises the core loop without input devices.</summary>
    public class GameSmokeTests
    {
        GameObject _root;

        [UnitySetUp]
        public IEnumerator SetUp()
        {
            Save.SaveSystem.Directory = System.IO.Path.Combine(Application.temporaryCachePath, "smoke_" + System.Guid.NewGuid().ToString("N"));
            _root = new GameObject("Game");
            _root.AddComponent<GameManager>();
            yield return null;
        }

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            Object.Destroy(_root);
            foreach (var name in new[] { "World", "Player", "Vehicle_SolaraCoupe", "Missions", "GameUI", "MinimapCamera", "EventSystem", "Main Camera", "Sun" })
            {
                var go = GameObject.Find(name);
                if (go != null) Object.Destroy(go);
            }
            Save.SaveSystem.Directory = null;
            Time.timeScale = 1f;
            yield return null;
        }

        [UnityTest]
        public IEnumerator Boots_IntoMainMenu_WithWorldBuilt()
        {
            var gm = GameManager.Instance;
            Assert.IsNotNull(gm);
            Assert.AreEqual(GameState.MainMenu, gm.State);
            Assert.IsNotNull(gm.Player);
            Assert.IsNotNull(gm.Vehicle);
            Assert.IsNotNull(GameObject.Find("City"));
            yield return null;
        }

        [UnityTest]
        public IEnumerator NewGame_PlayerStandsOnGround_VehicleSettles()
        {
            var gm = GameManager.Instance;
            gm.NewGame();
            Assert.AreEqual(GameState.Playing, gm.State);
            yield return new WaitForSeconds(2f);
            Assert.Greater(gm.Player.transform.position.y, -1f, "Player fell through the world");
            Assert.Greater(gm.Vehicle.transform.position.y, -1f, "Vehicle fell through the world");
            Assert.Less(gm.Vehicle.SpeedMs, 1f, "Parked vehicle should be at rest");
            Assert.Greater(Vector3.Dot(gm.Vehicle.transform.up, Vector3.up), 0.9f, "Vehicle should be upright");
        }

        [UnityTest]
        public IEnumerator EnterAndExitVehicle_Works()
        {
            var gm = GameManager.Instance;
            gm.NewGame();
            yield return new WaitForSeconds(0.5f);
            gm.Player.Teleport(gm.Vehicle.transform.position + gm.Vehicle.transform.right * -2f, 0f);
            yield return null;
            Assert.IsTrue(gm.CanEnterVehicle);
            gm.TryInteract();
            Assert.IsTrue(gm.IsDriving);
            Assert.IsFalse(gm.Player.gameObject.activeSelf);
            yield return null;
            gm.TryInteract();
            Assert.IsFalse(gm.IsDriving);
            Assert.IsTrue(gm.Player.gameObject.activeSelf);
        }

        [UnityTest]
        public IEnumerator SaveAndLoad_RestoresState()
        {
            var gm = GameManager.Instance;
            gm.NewGame();
            yield return new WaitForSeconds(0.3f);
            gm.Vehicle.SetHealth(42f);
            Assert.IsTrue(gm.SaveGame(out var msg), msg);
            gm.Vehicle.SetHealth(100f);
            Assert.IsTrue(gm.LoadGame(out msg), msg);
            Assert.AreEqual(42f, gm.Vehicle.Health, 0.01f);
        }

        [UnityTest]
        public IEnumerator PauseAndResume_ControlTimeScale()
        {
            var gm = GameManager.Instance;
            gm.NewGame();
            gm.Pause();
            Assert.AreEqual(0f, Time.timeScale);
            gm.Resume();
            Assert.AreEqual(1f, Time.timeScale);
            yield return null;
        }
    }
}
